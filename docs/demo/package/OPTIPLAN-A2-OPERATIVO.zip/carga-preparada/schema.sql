-- PREPARED ONLY. Requires specific authorization, backup and catalog preflight.
-- Repairs the observed 076 drift, installs 086 RPCs and adopts 087 without rewriting existing snapshots.
BEGIN;
SET LOCAL lock_timeout='5s';
SET LOCAL statement_timeout='60s';
DO $$ BEGIN
 IF current_setting('optiplan.confirmed_demo_project',true) IS DISTINCT FROM 'dyqusivzgxebkxkwohwn' THEN RAISE EXCEPTION 'WRONG_DEMO_PROJECT'; END IF;
 IF coalesce(current_setting('optiplan.backup_sha256',true),'') !~ '^[0-9a-f]{64}$' THEN RAISE EXCEPTION 'VERIFIED_BACKUP_REQUIRED'; END IF;
 IF coalesce(current_setting('optiplan.schema_approved',true),'') <> 'yes' THEN RAISE EXCEPTION 'SCHEMA_APPROVAL_REQUIRED'; END IF;
END $$;
ALTER TABLE public.plan_zone_settings
  ADD COLUMN IF NOT EXISTS config_source TEXT NOT NULL DEFAULT 'LEGACY_BACKFILL',
  ADD COLUMN IF NOT EXISTS name TEXT,
  ADD COLUMN IF NOT EXISTS meal_start_preferred TEXT,
  ADD COLUMN IF NOT EXISTS meal_end_preferred TEXT,
  ADD COLUMN IF NOT EXISTS grouping_level INTEGER,
  ADD COLUMN IF NOT EXISTS grouping_min_chain INTEGER,
  ADD COLUMN IF NOT EXISTS max_template_changes INTEGER,
  ADD COLUMN IF NOT EXISTS space_meal_break_minutes INTEGER;

ALTER TABLE public.plan_space_settings
  ADD COLUMN IF NOT EXISTS config_source TEXT NOT NULL DEFAULT 'LEGACY_BACKFILL',
  ADD COLUMN IF NOT EXISTS name TEXT,
  ADD COLUMN IF NOT EXISTS parent_space_id INTEGER,
  ADD COLUMN IF NOT EXISTS priority_level INTEGER,
  ADD COLUMN IF NOT EXISTS grouping_level INTEGER,
  ADD COLUMN IF NOT EXISTS grouping_min_chain INTEGER,
  ADD COLUMN IF NOT EXISTS grouping_apply_to_descendants BOOLEAN;


CREATE TABLE IF NOT EXISTS public.plan_resource_bundle_snapshots (
  id BIGSERIAL PRIMARY KEY,
  plan_id INTEGER NOT NULL REFERENCES public.plans(id) ON DELETE CASCADE,
  contract_version INTEGER NOT NULL DEFAULT 1 CHECK (contract_version = 1),
  source TEXT NOT NULL CHECK (source IN ('INHERITED', 'LEGACY_BACKFILL', 'DAY_OVERRIDE')),
  bundles JSONB NOT NULL DEFAULT '[]'::jsonb CHECK (jsonb_typeof(bundles) = 'array'),
  components JSONB NOT NULL DEFAULT '[]'::jsonb CHECK (jsonb_typeof(components) = 'array'),
  space_affinities JSONB NOT NULL DEFAULT '[]'::jsonb CHECK (jsonb_typeof(space_affinities) = 'array'),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT plan_resource_bundle_snapshots_plan_key UNIQUE (plan_id)
);


ALTER TABLE public.plan_resource_bundle_snapshots ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON TABLE public.plan_resource_bundle_snapshots FROM anon, authenticated;
REVOKE ALL ON SEQUENCE public.plan_resource_bundle_snapshots_id_seq FROM anon, authenticated;
GRANT ALL ON TABLE public.plan_resource_bundle_snapshots TO service_role;
GRANT ALL ON SEQUENCE public.plan_resource_bundle_snapshots_id_seq TO service_role;

-- Persist the explicit physical resource assignment carried by Assisted snapshot v1.
CREATE OR REPLACE FUNCTION public.assisted_apply_snapshot(p_plan_id integer, p_snapshot jsonb)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE item jsonb; expected_ids integer[]; actual_ids integer[];
BEGIN
  SELECT coalesce(array_agg((x->>'taskId')::integer ORDER BY (x->>'taskId')::integer),'{}')
    INTO expected_ids FROM jsonb_array_elements(p_snapshot->'tasks') x;
  SELECT coalesce(array_agg(id ORDER BY id),'{}') INTO actual_ids FROM public.daily_tasks WHERE plan_id=p_plan_id;
  IF expected_ids IS DISTINCT FROM actual_ids THEN RAISE EXCEPTION 'TASK_SET_MISMATCH'; END IF;
  FOR item IN SELECT value FROM jsonb_array_elements(p_snapshot->'tasks') LOOP
    UPDATE public.daily_tasks SET start_planned=item->>'startPlanned',end_planned=item->>'endPlanned',
      zone_id=(item->>'zoneId')::integer,space_id=(item->>'spaceId')::integer,
      location_label=item->>'locationLabel',duration_override=(item->>'durationOverride')::integer,
      cameras_override=(item->>'camerasOverride')::integer,
      assigned_resource_ids=CASE WHEN item ? 'assignedResourceIds' THEN item->'assignedResourceIds' ELSE assigned_resource_ids END
    WHERE plan_id=p_plan_id AND id=(item->>'taskId')::integer;
  END LOOP;
END $$;

CREATE OR REPLACE FUNCTION public.assisted_bootstrap_session(
  p_plan_id integer,p_user_id uuid,p_identity jsonb,p_replay jsonb,p_snapshot jsonb,p_fingerprint text)
RETURNS bigint LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE s public.assisted_planning_sessions%rowtype; revision_id bigint; parent_id bigint; stage_id bigint; current_snapshot jsonb;
BEGIN
  PERFORM pg_catalog.pg_advisory_xact_lock(78004,p_plan_id);
  SELECT * INTO s FROM public.assisted_planning_sessions WHERE plan_id=p_plan_id AND status='ACTIVE';
  IF FOUND THEN RETURN s.id; END IF;
  PERFORM 1 FROM public.daily_tasks WHERE plan_id=p_plan_id FOR SHARE;
  SELECT jsonb_build_object('contractVersion',1,'tasks',coalesce(jsonb_agg(jsonb_build_object(
    'taskId',id,'startPlanned',start_planned,'endPlanned',end_planned,'zoneId',zone_id,'spaceId',space_id,
    'locationLabel',location_label,'durationOverride',duration_override,'camerasOverride',cameras_override,
    'assignedResourceIds',coalesce(assigned_resource_ids,'[]'::jsonb)) ORDER BY id),'[]'::jsonb))
    INTO current_snapshot FROM public.daily_tasks WHERE plan_id=p_plan_id;
  IF current_snapshot IS DISTINCT FROM p_snapshot THEN RAISE EXCEPTION 'STALE_DRAFT'; END IF;
  SELECT id INTO parent_id FROM public.plan_config_revisions WHERE plan_id=p_plan_id ORDER BY created_at DESC,id DESC LIMIT 1;
  IF parent_id IS NOT NULL AND EXISTS(SELECT 1 FROM public.plan_config_revisions WHERE id=parent_id AND fingerprint=p_identity->>'configurationFingerprint') THEN revision_id:=parent_id;
  ELSE
    INSERT INTO public.plan_config_revisions(plan_id,parent_revision_id,source,fingerprint,identity_json,replay_snapshot_json,created_by)
    VALUES(p_plan_id,parent_id,'ASSISTED_BOOTSTRAP',p_identity->>'configurationFingerprint',p_identity,p_replay,p_user_id) RETURNING id INTO revision_id;
  END IF;
  INSERT INTO public.assisted_planning_sessions(plan_id,status,current_config_revision_id,draft_scope_json,draft_snapshot_json,draft_fingerprint)
    VALUES(p_plan_id,'ACTIVE',revision_id,'{}',p_snapshot,p_fingerprint) RETURNING id INTO s.id;
  INSERT INTO public.assisted_planning_stages(session_id,plan_id,ordinal,parent_stage_id,scope_json,scope_task_ids_json,include_prerequisites,config_revision_id,proposal_run_id,snapshot_json,snapshot_fingerprint,validation_summary_json,accepted_by,accepted_at)
    VALUES(s.id,p_plan_id,0,NULL,'{}','[]',false,revision_id,NULL,p_snapshot,p_fingerprint,'{"hardCount":0,"requiredCount":0,"preferredCount":0,"bootstrap":true}',p_user_id,now()) RETURNING id INTO stage_id;
  UPDATE public.assisted_planning_sessions SET active_stage_id=stage_id,draft_base_stage_id=stage_id WHERE id=s.id;
  RETURN s.id;
END $$;

CREATE OR REPLACE FUNCTION public.assisted_accept_stage(p_plan_id integer,p_user_id uuid,p_expected_fingerprint text,p_expected_base bigint,p_confirmation text DEFAULT 'NONE')
RETURNS bigint LANGUAGE plpgsql SECURITY INVOKER SET search_path='' AS $$
DECLARE s public.assisted_planning_sessions%rowtype; v public.planning_stage_validations%rowtype; new_id bigint; next_ordinal integer; item jsonb; task_item jsonb;
BEGIN
 IF p_confirmation NOT IN ('NONE','REQUIRED_DEVIATIONS','HARD_EXCEPTIONS') THEN RAISE EXCEPTION 'INVALID_CONFIRMATION'; END IF;
 SELECT * INTO s FROM public.assisted_planning_sessions WHERE plan_id=p_plan_id AND status='ACTIVE' FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'SESSION_NOT_FOUND'; END IF;
 IF s.draft_base_stage_id IS DISTINCT FROM p_expected_base THEN RAISE EXCEPTION 'STALE_BASE_STAGE'; END IF;
 IF s.draft_fingerprint<>p_expected_fingerprint THEN RAISE EXCEPTION 'STALE_DRAFT'; END IF;
 SELECT * INTO v FROM public.planning_stage_validations WHERE id=s.draft_validation_id AND session_id=s.id AND plan_id=p_plan_id FOR SHARE;
 IF NOT FOUND OR v.draft_fingerprint<>s.draft_fingerprint OR v.config_revision_id<>s.current_config_revision_id OR v.base_stage_id IS DISTINCT FROM s.draft_base_stage_id THEN RAISE EXCEPTION 'STALE_VALIDATION'; END IF;
 IF coalesce((v.report_json->>'newHardCount')::integer,v.hard_count)>0 AND p_confirmation<>'HARD_EXCEPTIONS' THEN RAISE EXCEPTION 'HARD_CONFIRMATION_REQUIRED'; END IF;
 IF coalesce((v.report_json->>'newRequiredCount')::integer,v.required_count)>0 AND p_confirmation NOT IN ('REQUIRED_DEVIATIONS','HARD_EXCEPTIONS') THEN RAISE EXCEPTION 'REQUIRED_CONFIRMATION_REQUIRED'; END IF;
 IF (SELECT coalesce(array_agg((x->>'taskId')::integer ORDER BY (x->>'taskId')::integer),'{}') FROM jsonb_array_elements(s.draft_snapshot_json->'tasks') x)
    IS DISTINCT FROM (SELECT coalesce(array_agg(id ORDER BY id),'{}') FROM public.daily_tasks WHERE plan_id=p_plan_id)
 THEN RAISE EXCEPTION 'TASK_SET_MISMATCH'; END IF;
 FOR task_item IN SELECT value FROM jsonb_array_elements(s.draft_snapshot_json->'tasks') LOOP
   UPDATE public.daily_tasks SET start_planned=task_item->>'startPlanned',end_planned=task_item->>'endPlanned',zone_id=(task_item->>'zoneId')::integer,
     space_id=(task_item->>'spaceId')::integer,location_label=task_item->>'locationLabel',duration_override=(task_item->>'durationOverride')::integer,
     cameras_override=(task_item->>'camerasOverride')::integer,
     assigned_resource_ids=CASE WHEN task_item ? 'assignedResourceIds' THEN task_item->'assignedResourceIds' ELSE assigned_resource_ids END
   WHERE plan_id=p_plan_id AND id=(task_item->>'taskId')::integer;
 END LOOP;
 WITH RECURSIVE obsolete AS (SELECT id FROM public.assisted_planning_stages WHERE session_id=s.id AND parent_stage_id=s.draft_base_stage_id AND archived_at IS NULL UNION ALL SELECT child.id FROM public.assisted_planning_stages child JOIN obsolete parent ON child.parent_stage_id=parent.id WHERE child.session_id=s.id AND child.archived_at IS NULL)
 UPDATE public.assisted_planning_stages SET archived_at=now() WHERE id IN (SELECT id FROM obsolete);
 SELECT coalesce(max(ordinal),-1)+1 INTO next_ordinal FROM public.assisted_planning_stages WHERE session_id=s.id;
 INSERT INTO public.assisted_planning_stages(session_id,plan_id,ordinal,parent_stage_id,scope_json,scope_task_ids_json,include_prerequisites,config_revision_id,proposal_run_id,snapshot_json,snapshot_fingerprint,validation_summary_json,accepted_by,accepted_at)
 VALUES(s.id,p_plan_id,next_ordinal,s.draft_base_stage_id,s.draft_scope_json,
   coalesce(s.draft_scope_json->'resolvedTaskIds',s.draft_scope_json->'originalScope'->'resolvedTaskIds','[]'::jsonb),
   coalesce((s.draft_scope_json->>'includePrerequisites')::boolean,(s.draft_scope_json->'originalScope'->>'includePrerequisites')::boolean,false),
   s.current_config_revision_id,
   CASE WHEN s.draft_scope_json->>'editKind' IS DISTINCT FROM 'MANUAL' THEN (s.draft_scope_json->>'proposalRunId')::bigint ELSE NULL END,
   s.draft_snapshot_json,s.draft_fingerprint,
   jsonb_build_object('hardValid',v.hard_count=0,'hardCount',v.hard_count,'requiredCount',v.required_count,'preferredCount',v.preferred_count,'validationId',v.id,'report',v.report_json),p_user_id,now()) RETURNING id INTO new_id;
 FOR item IN SELECT value FROM jsonb_array_elements(v.report_json->'violations') WHERE value->>'severity' IN ('HARD','REQUIRED') AND value->>'inheritedAcceptedExceptionId' IS NULL LOOP
   INSERT INTO public.planning_accepted_exceptions(plan_id,stage_id,severity,rule_code,violation_key,config_revision_id,snapshot_fingerprint,affected_task_ids_json,affected_resource_ids_json,affected_space_ids_json,details_json,status,accepted_by,accepted_at)
   VALUES(p_plan_id,new_id,item->>'severity',item->>'ruleCode',item->>'violationKey',s.current_config_revision_id,s.draft_fingerprint,item->'affectedTaskIds',coalesce(item->'affectedResourceIds','[]'),coalesce(item->'affectedSpaceIds','[]'),coalesce(item->'details','{}'),'ACTIVE',p_user_id,now());
 END LOOP;
 WITH RECURSIVE lineage AS (
   SELECT id,parent_stage_id,snapshot_json FROM public.assisted_planning_stages WHERE id=s.draft_base_stage_id AND session_id=s.id
   UNION ALL SELECT parent.id,parent.parent_stage_id,parent.snapshot_json FROM public.assisted_planning_stages parent JOIN lineage child ON parent.id=child.parent_stage_id WHERE parent.session_id=s.id
 ) UPDATE public.planning_accepted_exceptions exception SET status='SUPERSEDED',resolved_at=now()
 FROM lineage origin WHERE exception.stage_id=origin.id AND exception.status='ACTIVE'
   AND EXISTS(SELECT 1 FROM jsonb_array_elements(exception.affected_task_ids_json) affected WHERE
     (SELECT task FROM jsonb_array_elements(origin.snapshot_json->'tasks') task WHERE task->>'taskId'=affected#>>'{}') IS DISTINCT FROM
     (SELECT task FROM jsonb_array_elements(s.draft_snapshot_json->'tasks') task WHERE task->>'taskId'=affected#>>'{}'));
 UPDATE public.assisted_planning_sessions SET active_stage_id=new_id,draft_base_stage_id=new_id,draft_scope_json='{}',draft_validation_id=NULL,updated_at=now() WHERE id=s.id;
 RETURN new_id;
EXCEPTION WHEN unique_violation THEN RAISE EXCEPTION 'CONCURRENT_ACCEPT'; END $$;


REVOKE ALL ON FUNCTION public.assisted_apply_snapshot(integer,jsonb), public.assisted_bootstrap_session(integer,uuid,jsonb,jsonb,jsonb,text), public.assisted_accept_stage(integer,uuid,text,bigint,text) FROM PUBLIC,anon,authenticated,service_role;
GRANT EXECUTE ON FUNCTION public.assisted_bootstrap_session(integer,uuid,jsonb,jsonb,jsonb,text), public.assisted_accept_stage(integer,uuid,text,bigint,text) TO service_role;

ALTER TABLE public.program_settings
  ADD COLUMN IF NOT EXISTS default_participant_transition_minutes INTEGER NOT NULL DEFAULT 5
  CHECK (default_participant_transition_minutes >= 0);

ALTER TABLE public.plans
  ADD COLUMN IF NOT EXISTS participant_transition_minutes INTEGER NOT NULL DEFAULT 5 CHECK (participant_transition_minutes >= 0),
  ADD COLUMN IF NOT EXISTS participant_transition_baseline_minutes INTEGER NOT NULL DEFAULT 5 CHECK (participant_transition_baseline_minutes >= 0),
  ADD COLUMN IF NOT EXISTS participant_transition_config_source TEXT NOT NULL DEFAULT 'LEGACY_BACKFILL'
    CHECK (participant_transition_config_source IN ('INHERITED','DAY_OVERRIDE','LEGACY_BACKFILL')),
  ADD COLUMN IF NOT EXISTS participant_transition_override_by UUID REFERENCES auth.users(id),
  ADD COLUMN IF NOT EXISTS participant_transition_override_at TIMESTAMPTZ;
ALTER TABLE public.plans DROP CONSTRAINT IF EXISTS plans_participant_transition_provenance_check;
ALTER TABLE public.plans ADD CONSTRAINT plans_participant_transition_provenance_check CHECK (
  (participant_transition_config_source='INHERITED' AND participant_transition_minutes=participant_transition_baseline_minutes AND participant_transition_override_by IS NULL AND participant_transition_override_at IS NULL)
  OR (participant_transition_config_source='DAY_OVERRIDE' AND participant_transition_override_by IS NOT NULL AND participant_transition_override_at IS NOT NULL)
  OR (participant_transition_config_source='LEGACY_BACKFILL' AND participant_transition_override_by IS NULL AND participant_transition_override_at IS NULL)
) NOT VALID;
ALTER TABLE public.plans VALIDATE CONSTRAINT plans_participant_transition_provenance_check;

ALTER TABLE public.task_templates
  ADD COLUMN IF NOT EXISTS participant_margin_before_minutes INTEGER CHECK (participant_margin_before_minutes >= 0),
  ADD COLUMN IF NOT EXISTS participant_margin_after_minutes INTEGER CHECK (participant_margin_after_minutes >= 0);

ALTER TABLE public.daily_tasks
  ADD COLUMN IF NOT EXISTS participant_margin_before_minutes INTEGER CHECK (participant_margin_before_minutes >= 0),
  ADD COLUMN IF NOT EXISTS participant_margin_after_minutes INTEGER CHECK (participant_margin_after_minutes >= 0);

ALTER TABLE public.plan_task_template_snapshots
  ADD COLUMN IF NOT EXISTS participant_margin_before_minutes INTEGER CHECK (participant_margin_before_minutes >= 0),
  ADD COLUMN IF NOT EXISTS participant_margin_after_minutes INTEGER CHECK (participant_margin_after_minutes >= 0);

ALTER TABLE public.plan_task_template_snapshots DROP CONSTRAINT IF EXISTS plan_task_template_snapshots_contract_version_check;
-- Preserve all existing v1 snapshots. The application normalizer supports v1 and v2.
ALTER TABLE public.plan_task_template_snapshots ALTER COLUMN contract_version SET DEFAULT 2;
ALTER TABLE public.plan_task_template_snapshots ADD CONSTRAINT plan_task_template_snapshots_contract_version_check CHECK (contract_version IN (1,2));

CREATE OR REPLACE FUNCTION public.apply_day_config_operation(
  p_plan_id integer, p_actor uuid, p_operation text, p_payload jsonb,
  p_expected_revision bigint, p_expected_identity jsonb, p_expected_replay jsonb,
  p_candidate_identity jsonb, p_candidate_replay jsonb, p_diff jsonb
) RETURNS bigint LANGUAGE plpgsql SECURITY INVOKER SET search_path=public AS $$
DECLARE p public.plans%ROWTYPE; g public.program_settings%ROWTYPE; cap text;
  parent_revision bigint; new_revision bigint; persisted_fingerprint text;
BEGIN
  SELECT * INTO p FROM public.plans WHERE id=p_plan_id FOR UPDATE;
  IF p.id IS NULL THEN RAISE EXCEPTION 'PLAN_NOT_FOUND'; END IF;
  IF p.current_config_revision_id IS DISTINCT FROM p_expected_revision THEN RAISE EXCEPTION 'STALE_CONFIG_REVISION'; END IF;
  IF p_expected_identity->>'contractVersion'<>'1' OR (p_expected_identity->>'planId')::integer<>p_plan_id
     OR p_expected_replay->>'contractVersion'<>'1' OR p_expected_identity->>'configurationFingerprint' IS NULL
     OR p_candidate_identity->>'contractVersion'<>'1' OR (p_candidate_identity->>'planId')::integer<>p_plan_id
     OR p_candidate_replay->>'contractVersion'<>'1' OR p_candidate_identity->>'configurationFingerprint' IS NULL
     THEN RAISE EXCEPTION 'INVALID_CONFIG_REVISION_CONTRACT'; END IF;

  parent_revision:=p.current_config_revision_id;
  IF parent_revision IS NOT NULL THEN
    SELECT fingerprint INTO persisted_fingerprint FROM public.plan_config_revisions
      WHERE id=parent_revision AND plan_id=p_plan_id FOR UPDATE;
  END IF;
  -- A missing or stale legacy pointer is repaired only with a full canonical
  -- snapshot of the pre-mutation effective configuration.
  IF persisted_fingerprint IS DISTINCT FROM p_expected_identity->>'configurationFingerprint' THEN
    INSERT INTO public.plan_config_revisions(plan_id,parent_revision_id,source,fingerprint,identity_json,replay_snapshot_json,diff_json,created_by)
    VALUES(p_plan_id,parent_revision,'CANONICAL_MATERIALIZATION',p_expected_identity->>'configurationFingerprint',p_expected_identity,p_expected_replay,
      jsonb_build_object('reason','legacy-or-stale-current-revision'),p_actor) RETURNING id INTO parent_revision;
  END IF;

  IF p_operation='EDIT' THEN
    IF p_payload ? 'workday' THEN UPDATE public.plans SET work_start=p_payload#>>'{workday,start}',work_end=p_payload#>>'{workday,end}',work_config_source='DAY_OVERRIDE',work_override_by=p_actor,work_override_at=now() WHERE id=p_plan_id; END IF;
    IF p_payload ? 'meal' THEN UPDATE public.plans SET meal_start=p_payload#>>'{meal,start}',meal_end=p_payload#>>'{meal,end}',meal_mode=p_payload#>>'{meal,mode}',meal_config_source='DAY_OVERRIDE',meal_override_by=p_actor,meal_override_at=now() WHERE id=p_plan_id; END IF;
    IF p_payload ? 'participantTransitionMinutes' THEN UPDATE public.plans SET participant_transition_minutes=(p_payload->>'participantTransitionMinutes')::int,participant_transition_config_source='DAY_OVERRIDE',participant_transition_override_by=p_actor,participant_transition_override_at=now() WHERE id=p_plan_id; END IF;
  ELSIF p_operation='RESTORE' THEN
    cap:=p_payload->>'capability';
    IF cap='WORKDAY_WINDOW' THEN UPDATE public.plans SET work_start=work_baseline_start,work_end=work_baseline_end,work_config_source='INHERITED',work_override_by=NULL,work_override_at=NULL WHERE id=p_plan_id;
    ELSIF cap='GLOBAL_MEAL_BREAK' THEN UPDATE public.plans SET meal_start=meal_baseline_start,meal_end=meal_baseline_end,meal_mode=meal_baseline_mode,meal_config_source='INHERITED',meal_override_by=NULL,meal_override_at=NULL WHERE id=p_plan_id;
    ELSIF cap='PARTICIPANT_TRANSITION' THEN UPDATE public.plans SET participant_transition_minutes=participant_transition_baseline_minutes,participant_transition_config_source='INHERITED',participant_transition_override_by=NULL,participant_transition_override_at=NULL WHERE id=p_plan_id;
    ELSE RAISE EXCEPTION 'INVALID_CAPABILITY'; END IF;
  ELSIF p_operation='REFRESH' THEN
    SELECT * INTO g FROM public.program_settings WHERE id=1;
    IF p_payload->'capabilities' ? 'WORKDAY_WINDOW' AND (p.work_config_source<>'LEGACY_BACKFILL' OR p_payload->>'legacyTreatment'='ADOPT_GENERAL_AS_INHERITED') THEN
      UPDATE public.plans SET work_baseline_start=g.default_work_start,work_baseline_end=g.default_work_end,
        work_start=CASE WHEN p.work_config_source='DAY_OVERRIDE' THEN work_start ELSE g.default_work_start END,
        work_end=CASE WHEN p.work_config_source='DAY_OVERRIDE' THEN work_end ELSE g.default_work_end END,
        work_config_source=CASE WHEN p.work_config_source='LEGACY_BACKFILL' THEN 'INHERITED' ELSE p.work_config_source END,
        work_override_by=CASE WHEN p.work_config_source='DAY_OVERRIDE' THEN work_override_by ELSE NULL END,
        work_override_at=CASE WHEN p.work_config_source='DAY_OVERRIDE' THEN work_override_at ELSE NULL END WHERE id=p_plan_id;
    END IF;
    IF p_payload->'capabilities' ? 'GLOBAL_MEAL_BREAK' AND (p.meal_config_source<>'LEGACY_BACKFILL' OR p_payload->>'legacyTreatment'='ADOPT_GENERAL_AS_INHERITED') THEN
      UPDATE public.plans SET meal_baseline_start=g.meal_start,meal_baseline_end=g.meal_end,meal_baseline_mode=g.meal_mode,
        meal_start=CASE WHEN p.meal_config_source='DAY_OVERRIDE' THEN meal_start ELSE g.meal_start END,
        meal_end=CASE WHEN p.meal_config_source='DAY_OVERRIDE' THEN meal_end ELSE g.meal_end END,
        meal_mode=CASE WHEN p.meal_config_source='DAY_OVERRIDE' THEN meal_mode ELSE g.meal_mode END,
        meal_config_source=CASE WHEN p.meal_config_source='LEGACY_BACKFILL' THEN 'INHERITED' ELSE p.meal_config_source END,
        meal_override_by=CASE WHEN p.meal_config_source='DAY_OVERRIDE' THEN meal_override_by ELSE NULL END,
        meal_override_at=CASE WHEN p.meal_config_source='DAY_OVERRIDE' THEN meal_override_at ELSE NULL END WHERE id=p_plan_id;
    END IF;
    IF p_payload->'capabilities' ? 'PARTICIPANT_TRANSITION' AND (p.participant_transition_config_source<>'LEGACY_BACKFILL' OR p_payload->>'legacyTreatment'='ADOPT_GENERAL_AS_INHERITED') THEN
      UPDATE public.plans SET participant_transition_baseline_minutes=g.default_participant_transition_minutes,
        participant_transition_minutes=CASE WHEN p.participant_transition_config_source='DAY_OVERRIDE' THEN participant_transition_minutes ELSE g.default_participant_transition_minutes END,
        participant_transition_config_source=CASE WHEN p.participant_transition_config_source='LEGACY_BACKFILL' THEN 'INHERITED' ELSE p.participant_transition_config_source END,
        participant_transition_override_by=CASE WHEN p.participant_transition_config_source='DAY_OVERRIDE' THEN participant_transition_override_by ELSE NULL END,
        participant_transition_override_at=CASE WHEN p.participant_transition_config_source='DAY_OVERRIDE' THEN participant_transition_override_at ELSE NULL END WHERE id=p_plan_id;
    END IF;
  ELSE RAISE EXCEPTION 'INVALID_OPERATION'; END IF;

  -- Re-lock/read after mutation and reject a server candidate built for any
  -- different effective workday/meal state. Contestant values are never inferred.
  SELECT * INTO p FROM public.plans WHERE id=p_plan_id;
  IF NOT EXISTS (SELECT 1 FROM jsonb_array_elements(p_candidate_replay#>'{authorities,plan_workday}') w
    WHERE w#>>'{workDay,start}'=p.work_start AND w#>>'{workDay,end}'=p.work_end
      AND w->>'mealMode'=p.meal_mode
      AND (w#>>'{mealWindow,start}'=p.meal_start OR w#>>'{meal,start}'=p.meal_start)
      AND (w#>>'{mealWindow,end}'=p.meal_end OR w#>>'{meal,end}'=p.meal_end)
      AND (w->>'defaultParticipantTransitionMinutes')::int=p.participant_transition_minutes)
    THEN RAISE EXCEPTION 'STALE_CONFIG_CANDIDATE'; END IF;

  INSERT INTO public.plan_config_revisions(plan_id,parent_revision_id,source,fingerprint,identity_json,replay_snapshot_json,diff_json,created_by)
  VALUES(p_plan_id,parent_revision,p_operation,p_candidate_identity->>'configurationFingerprint',p_candidate_identity,p_candidate_replay,p_diff,p_actor)
  RETURNING id INTO new_revision;
  UPDATE public.plans SET current_config_revision_id=new_revision WHERE id=p_plan_id;
  UPDATE public.assisted_planning_sessions SET current_config_revision_id=new_revision,draft_validation_id=NULL,updated_at=now()
    WHERE plan_id=p_plan_id AND status='ACTIVE';
  RETURN new_revision;
END $$;

CREATE OR REPLACE FUNCTION public.initialize_day_config_revision(
  p_plan_id integer, p_actor uuid, p_identity jsonb, p_replay jsonb, p_diff jsonb
) RETURNS bigint LANGUAGE plpgsql SECURITY INVOKER SET search_path=public AS $$
DECLARE p public.plans%ROWTYPE; new_revision bigint;
BEGIN
  SELECT * INTO p FROM public.plans WHERE id=p_plan_id FOR UPDATE;
  IF p.id IS NULL THEN RAISE EXCEPTION 'PLAN_NOT_FOUND'; END IF;
  IF p.current_config_revision_id IS NOT NULL THEN RAISE EXCEPTION 'CONFIG_REVISION_ALREADY_INITIALIZED'; END IF;
  IF p_identity->>'contractVersion'<>'1' OR (p_identity->>'planId')::integer<>p_plan_id
    OR p_identity->>'configurationFingerprint' IS NULL OR p_replay->>'contractVersion'<>'1'
    THEN RAISE EXCEPTION 'INVALID_CONFIG_REVISION_CONTRACT'; END IF;
  INSERT INTO public.plan_config_revisions(plan_id,source,fingerprint,identity_json,replay_snapshot_json,diff_json,created_by)
  VALUES(p_plan_id,'DAY_CREATED',p_identity->>'configurationFingerprint',p_identity,p_replay,p_diff,p_actor)
  RETURNING id INTO new_revision;
  UPDATE public.plans SET current_config_revision_id=new_revision WHERE id=p_plan_id;
  RETURN new_revision;
END $$;

REVOKE ALL ON FUNCTION public.apply_day_config_operation(integer,uuid,text,jsonb,bigint,jsonb,jsonb,jsonb,jsonb,jsonb),
  public.initialize_day_config_revision(integer,uuid,jsonb,jsonb,jsonb) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.apply_day_config_operation(integer,uuid,text,jsonb,bigint,jsonb,jsonb,jsonb,jsonb,jsonb),
  public.initialize_day_config_revision(integer,uuid,jsonb,jsonb,jsonb) TO service_role;

-- Re-project config refresh losslessly under snapshot contract v2.
CREATE OR REPLACE FUNCTION public.assisted_apply_config_refresh(
  p_plan_id INTEGER, p_user_id UUID, p_expected_revision BIGINT,
  p_identity JSONB, p_replay JSONB, p_diff JSONB
) RETURNS BIGINT LANGUAGE plpgsql SECURITY INVOKER SET search_path=public AS $$
DECLARE s public.assisted_planning_sessions%ROWTYPE; new_revision BIGINT; item JSONB; optimizer JSONB; affected_rows INTEGER;
BEGIN
  SELECT * INTO s FROM public.assisted_planning_sessions WHERE plan_id=p_plan_id AND status='ACTIVE' FOR UPDATE;
  IF s.id IS NULL THEN RAISE EXCEPTION 'SESSION_NOT_FOUND'; END IF;
  IF s.current_config_revision_id<>p_expected_revision THEN RAISE EXCEPTION 'STALE_CONFIG_REVISION'; END IF;
  IF p_identity->>'configurationFingerprint'=(SELECT fingerprint FROM public.plan_config_revisions WHERE id=p_expected_revision) THEN RAISE EXCEPTION 'NO_CHANGES'; END IF;
  IF jsonb_typeof(p_replay->'taskTemplateSnapshots') IS DISTINCT FROM 'array'
     OR jsonb_typeof(p_replay->'optimizerSnapshot') IS DISTINCT FROM 'object'
     OR p_identity->>'configurationFingerprint' IS NULL THEN RAISE EXCEPTION 'INVALID_REFRESH_REPLAY'; END IF;
  IF EXISTS (SELECT 1 FROM jsonb_array_elements(p_replay->'taskTemplateSnapshots') x
             GROUP BY (x->>'sourceTemplateId')::int HAVING count(*)<>1) THEN RAISE EXCEPTION 'INVALID_REFRESH_REPLAY'; END IF;

  -- Replace only the versioned daily catalogs represented by the replay. No
  -- placements, daily_tasks, stages, validations or accepted exceptions are updated.
  FOR item IN SELECT * FROM jsonb_array_elements(p_replay->'taskTemplateSnapshots') LOOP
    INSERT INTO public.plan_task_template_snapshots(plan_id,source_template_id,contract_version,source,template_name,default_duration,default_cameras,default_zone_id,default_space_id,auto_create_on_contestant_create,requires_auxiliar,requires_coach,requires_presenter,exclusive_auxiliar,has_dependency,dependency_template_ids,resource_requirements,itinerant_team_requirement,itinerant_team_id,allowed_itinerant_team_ids,setup_id,participant_margin_before_minutes,participant_margin_after_minutes)
    VALUES(p_plan_id,(item->>'sourceTemplateId')::int,2,item->>'source',item->>'templateName',(item->>'defaultDuration')::int,(item->>'defaultCameras')::int,(item->>'defaultZoneId')::int,(item->>'defaultSpaceId')::int,(item->>'autoCreateOnContestantCreate')::bool,(item->>'requiresAuxiliar')::bool,(item->>'requiresCoach')::bool,(item->>'requiresPresenter')::bool,(item->>'exclusiveAuxiliar')::bool,(item->>'hasDependency')::bool,item->'dependencyTemplateIds',NULLIF(item->'resourceRequirements','null'::jsonb),item->>'itinerantTeamRequirement',(item->>'itinerantTeamId')::int,item->'allowedItinerantTeamIds',(item->>'setupId')::int,(item->>'participantMarginBeforeMinutes')::int,(item->>'participantMarginAfterMinutes')::int)
    ON CONFLICT(plan_id,source_template_id) DO UPDATE SET source=EXCLUDED.source,template_name=EXCLUDED.template_name,default_duration=EXCLUDED.default_duration,default_cameras=EXCLUDED.default_cameras,default_zone_id=EXCLUDED.default_zone_id,default_space_id=EXCLUDED.default_space_id,auto_create_on_contestant_create=EXCLUDED.auto_create_on_contestant_create,requires_auxiliar=EXCLUDED.requires_auxiliar,requires_coach=EXCLUDED.requires_coach,requires_presenter=EXCLUDED.requires_presenter,exclusive_auxiliar=EXCLUDED.exclusive_auxiliar,has_dependency=EXCLUDED.has_dependency,dependency_template_ids=EXCLUDED.dependency_template_ids,resource_requirements=EXCLUDED.resource_requirements,itinerant_team_requirement=EXCLUDED.itinerant_team_requirement,itinerant_team_id=EXCLUDED.itinerant_team_id,allowed_itinerant_team_ids=EXCLUDED.allowed_itinerant_team_ids,setup_id=EXCLUDED.setup_id,participant_margin_before_minutes=EXCLUDED.participant_margin_before_minutes,participant_margin_after_minutes=EXCLUDED.participant_margin_after_minutes;
  END LOOP;
  optimizer:=p_replay->'optimizerSnapshot';
  UPDATE public.plan_optimizer_snapshots SET source=optimizer->>'source',editing_mode=optimizer->>'editingMode',main_zone_id=(optimizer->>'mainZoneId')::int,arrival_plan_template_snapshot_id=(optimizer#>>'{transport,arrivalPlanTemplateSnapshotId}')::bigint,departure_plan_template_snapshot_id=(optimizer#>>'{transport,departurePlanTemplateSnapshotId}')::bigint,arrival_grouping_target=(optimizer#>>'{transport,arrivalGroupingTarget}')::int,departure_grouping_target=(optimizer#>>'{transport,departureGroupingTarget}')::int,arrival_min_gap_minutes=(optimizer#>>'{transport,arrivalMinGapMinutes}')::int,departure_min_gap_minutes=(optimizer#>>'{transport,departureMinGapMinutes}')::int,van_capacity=(optimizer#>>'{transport,vanCapacity}')::int,grouping_weight=(optimizer#>>'{transport,groupingWeight}')::int,near_hard_breaks_max=(optimizer->>'nearHardBreaksMax')::int,updated_by=p_user_id,updated_at=now() WHERE plan_id=p_plan_id;
  GET DIAGNOSTICS affected_rows = ROW_COUNT;
  IF affected_rows<>1 THEN RAISE EXCEPTION 'REFRESH_REPLAY_NOT_MATERIALIZED'; END IF;
  DELETE FROM public.plan_optimizer_snapshot_heuristics h USING public.plan_optimizer_snapshots o WHERE h.snapshot_id=o.id AND o.plan_id=p_plan_id;
  INSERT INTO public.plan_optimizer_snapshot_heuristics(snapshot_id,heuristic_key,basic_level,advanced_value)
    SELECT o.id,h.key,(h.value->>'basicLevel')::int,(h.value->>'advancedValue')::int FROM public.plan_optimizer_snapshots o,jsonb_each(optimizer->'heuristics') h WHERE o.plan_id=p_plan_id;
  DELETE FROM public.plan_optimizer_snapshot_grouping_zones g USING public.plan_optimizer_snapshots o WHERE g.snapshot_id=o.id AND o.plan_id=p_plan_id;
  INSERT INTO public.plan_optimizer_snapshot_grouping_zones(snapshot_id,zone_id)
    SELECT o.id,(z#>>'{}')::int FROM public.plan_optimizer_snapshots o,jsonb_array_elements(optimizer->'groupingZoneIds') z WHERE o.plan_id=p_plan_id;
  DELETE FROM public.plan_task_template_snapshots t WHERE t.plan_id=p_plan_id AND NOT EXISTS(SELECT 1 FROM jsonb_array_elements(p_replay->'taskTemplateSnapshots') x WHERE (x->>'sourceTemplateId')::int=t.source_template_id);

  -- Do not persist a revision whose replay differs from the rows actually
  -- materialized. The transaction aborts atomically on any lossy projection.
  IF (SELECT count(*) FROM public.plan_task_template_snapshots WHERE plan_id=p_plan_id)
       <> jsonb_array_length(p_replay->'taskTemplateSnapshots')
     OR EXISTS (
       SELECT 1 FROM jsonb_array_elements(p_replay->'taskTemplateSnapshots') x
       LEFT JOIN public.plan_task_template_snapshots t ON t.plan_id=p_plan_id AND t.source_template_id=(x->>'sourceTemplateId')::int
       WHERE t.id IS NULL OR t.source IS DISTINCT FROM x->>'source'
          OR t.template_name IS DISTINCT FROM x->>'templateName'
          OR t.default_duration IS DISTINCT FROM (x->>'defaultDuration')::int
          OR t.default_cameras IS DISTINCT FROM (x->>'defaultCameras')::int
          OR t.default_zone_id IS DISTINCT FROM (x->>'defaultZoneId')::int
          OR t.default_space_id IS DISTINCT FROM (x->>'defaultSpaceId')::int
          OR t.auto_create_on_contestant_create IS DISTINCT FROM (x->>'autoCreateOnContestantCreate')::bool
          OR t.requires_auxiliar IS DISTINCT FROM (x->>'requiresAuxiliar')::bool
          OR t.requires_coach IS DISTINCT FROM (x->>'requiresCoach')::bool
          OR t.requires_presenter IS DISTINCT FROM (x->>'requiresPresenter')::bool
          OR t.exclusive_auxiliar IS DISTINCT FROM (x->>'exclusiveAuxiliar')::bool
          OR t.has_dependency IS DISTINCT FROM (x->>'hasDependency')::bool
          OR (SELECT COALESCE(jsonb_agg(v ORDER BY v::text),'[]'::jsonb) FROM jsonb_array_elements(t.dependency_template_ids) v)
             IS DISTINCT FROM (SELECT COALESCE(jsonb_agg(v ORDER BY v::text),'[]'::jsonb) FROM jsonb_array_elements(x->'dependencyTemplateIds') v)
          OR t.resource_requirements IS DISTINCT FROM NULLIF(x->'resourceRequirements','null'::jsonb)
          OR t.itinerant_team_requirement IS DISTINCT FROM x->>'itinerantTeamRequirement'
          OR t.itinerant_team_id IS DISTINCT FROM (x->>'itinerantTeamId')::int
          OR (SELECT COALESCE(jsonb_agg(v ORDER BY v::text),'[]'::jsonb) FROM jsonb_array_elements(t.allowed_itinerant_team_ids) v)
             IS DISTINCT FROM (SELECT COALESCE(jsonb_agg(v ORDER BY v::text),'[]'::jsonb) FROM jsonb_array_elements(x->'allowedItinerantTeamIds') v)
          OR t.setup_id IS DISTINCT FROM (x->>'setupId')::int
          OR t.participant_margin_before_minutes IS DISTINCT FROM (x->>'participantMarginBeforeMinutes')::int
          OR t.participant_margin_after_minutes IS DISTINCT FROM (x->>'participantMarginAfterMinutes')::int
     ) THEN RAISE EXCEPTION 'REFRESH_REPLAY_NOT_MATERIALIZED'; END IF;
  IF NOT EXISTS (SELECT 1 FROM public.plan_optimizer_snapshots o WHERE o.plan_id=p_plan_id
       AND o.source IS NOT DISTINCT FROM optimizer->>'source'
       AND o.editing_mode IS NOT DISTINCT FROM optimizer->>'editingMode'
       AND o.main_zone_id IS NOT DISTINCT FROM (optimizer->>'mainZoneId')::int
       AND o.arrival_plan_template_snapshot_id IS NOT DISTINCT FROM (optimizer#>>'{transport,arrivalPlanTemplateSnapshotId}')::bigint
       AND o.departure_plan_template_snapshot_id IS NOT DISTINCT FROM (optimizer#>>'{transport,departurePlanTemplateSnapshotId}')::bigint
       AND o.arrival_grouping_target IS NOT DISTINCT FROM (optimizer#>>'{transport,arrivalGroupingTarget}')::int
       AND o.departure_grouping_target IS NOT DISTINCT FROM (optimizer#>>'{transport,departureGroupingTarget}')::int
       AND o.arrival_min_gap_minutes IS NOT DISTINCT FROM (optimizer#>>'{transport,arrivalMinGapMinutes}')::int
       AND o.departure_min_gap_minutes IS NOT DISTINCT FROM (optimizer#>>'{transport,departureMinGapMinutes}')::int
       AND o.van_capacity IS NOT DISTINCT FROM (optimizer#>>'{transport,vanCapacity}')::int
       AND o.grouping_weight IS NOT DISTINCT FROM (optimizer#>>'{transport,groupingWeight}')::int
       AND o.near_hard_breaks_max IS NOT DISTINCT FROM (optimizer->>'nearHardBreaksMax')::int
       AND (SELECT count(*) FROM public.plan_optimizer_snapshot_heuristics h WHERE h.snapshot_id=o.id)=jsonb_object_length(optimizer->'heuristics')
       AND NOT EXISTS (
         SELECT 1 FROM jsonb_each(optimizer->'heuristics') expected
         LEFT JOIN public.plan_optimizer_snapshot_heuristics actual ON actual.snapshot_id=o.id AND actual.heuristic_key=expected.key
         WHERE actual.heuristic_key IS NULL
            OR actual.basic_level IS DISTINCT FROM (expected.value->>'basicLevel')::int
            OR actual.advanced_value IS DISTINCT FROM (expected.value->>'advancedValue')::int
       )
       AND (SELECT COALESCE(jsonb_agg(g.zone_id ORDER BY g.zone_id),'[]'::jsonb) FROM public.plan_optimizer_snapshot_grouping_zones g WHERE g.snapshot_id=o.id)
           IS NOT DISTINCT FROM (SELECT COALESCE(jsonb_agg((z#>>'{}')::int ORDER BY (z#>>'{}')::int),'[]'::jsonb) FROM jsonb_array_elements(optimizer->'groupingZoneIds') z))
     THEN RAISE EXCEPTION 'REFRESH_REPLAY_NOT_MATERIALIZED'; END IF;

  INSERT INTO public.plan_config_revisions(plan_id,parent_revision_id,source,fingerprint,identity_json,replay_snapshot_json,diff_json,created_by)
  VALUES(p_plan_id,p_expected_revision,'GENERAL_REFRESH',p_identity->>'configurationFingerprint',p_identity,p_replay,p_diff,p_user_id) RETURNING id INTO new_revision;
  UPDATE public.assisted_planning_sessions SET current_config_revision_id=new_revision,draft_validation_id=NULL,updated_at=now() WHERE id=s.id;
  RETURN new_revision;
END $$;
REVOKE ALL ON FUNCTION public.assisted_apply_config_refresh(INTEGER,UUID,BIGINT,JSONB,JSONB,JSONB) FROM PUBLIC,anon,authenticated;
GRANT EXECUTE ON FUNCTION public.assisted_apply_config_refresh(INTEGER,UUID,BIGINT,JSONB,JSONB,JSONB) TO service_role;

-- Prepared for the explicitly approved test project. Never applied by the importer.
-- NULL preserves existing days and their current engine behavior.
ALTER TABLE public.plans ADD COLUMN planner_next_configuration jsonb;
ALTER TABLE public.plans ADD CONSTRAINT plans_planner_next_configuration_shape CHECK (
 planner_next_configuration IS NULL OR
 (jsonb_typeof(planner_next_configuration)='object' AND
  planner_next_configuration->>'contractVersion'='1' AND
  jsonb_typeof(planner_next_configuration->'taskOperations')='array')
);
-- No route edits this contract. Future configuration editing needs an explicit
-- revision/refresh design; ordinary status/current-revision updates stay allowed.
CREATE FUNCTION public.preserve_plan_planner_next_configuration() RETURNS trigger
 LANGUAGE plpgsql SET search_path=public AS $$
BEGIN
 IF NEW.planner_next_configuration IS DISTINCT FROM OLD.planner_next_configuration THEN
  RAISE EXCEPTION 'PLANNER_NEXT_CONFIGURATION_IMMUTABLE';
 END IF;
 RETURN NEW;
END $$;
CREATE TRIGGER preserve_plan_planner_next_configuration BEFORE UPDATE ON public.plans
 FOR EACH ROW EXECUTE FUNCTION public.preserve_plan_planner_next_configuration();
REVOKE ALL ON FUNCTION public.preserve_plan_planner_next_configuration() FROM PUBLIC,anon,authenticated;

-- Reconcile public Assisted contracts by their source bodies, not ledger numbers.
CREATE OR REPLACE FUNCTION public.assisted_apply_snapshot(p_plan_id integer, p_snapshot jsonb)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE item jsonb; expected_ids integer[]; actual_ids integer[];
BEGIN
  SELECT coalesce(array_agg((x->>'taskId')::integer ORDER BY (x->>'taskId')::integer),'{}')
    INTO expected_ids FROM jsonb_array_elements(p_snapshot->'tasks') x;
  SELECT coalesce(array_agg(id ORDER BY id),'{}') INTO actual_ids FROM public.daily_tasks WHERE plan_id=p_plan_id;
  IF expected_ids IS DISTINCT FROM actual_ids THEN RAISE EXCEPTION 'TASK_SET_MISMATCH'; END IF;
  FOR item IN SELECT value FROM jsonb_array_elements(p_snapshot->'tasks') LOOP
    UPDATE public.daily_tasks SET start_planned=item->>'startPlanned',end_planned=item->>'endPlanned',
      zone_id=(item->>'zoneId')::integer,space_id=(item->>'spaceId')::integer,
      location_label=item->>'locationLabel',duration_override=(item->>'durationOverride')::integer,
      cameras_override=(item->>'camerasOverride')::integer,
      assigned_resource_ids=CASE WHEN item ? 'assignedResourceIds' THEN item->'assignedResourceIds' ELSE assigned_resource_ids END
    WHERE plan_id=p_plan_id AND id=(item->>'taskId')::integer;
  END LOOP;
END $$;
REVOKE ALL ON FUNCTION public.assisted_apply_snapshot(integer,jsonb) FROM PUBLIC,anon,authenticated,service_role;

CREATE OR REPLACE FUNCTION public.assisted_bootstrap_session(
  p_plan_id integer,p_user_id uuid,p_identity jsonb,p_replay jsonb,p_snapshot jsonb,p_fingerprint text)
RETURNS bigint LANGUAGE plpgsql SECURITY DEFINER SET search_path='' AS $$
DECLARE s public.assisted_planning_sessions%rowtype; revision_id bigint; parent_id bigint; stage_id bigint; current_snapshot jsonb;
BEGIN
  PERFORM pg_catalog.pg_advisory_xact_lock(78004,p_plan_id);
  SELECT * INTO s FROM public.assisted_planning_sessions WHERE plan_id=p_plan_id AND status='ACTIVE';
  IF FOUND THEN RETURN s.id; END IF;
  PERFORM 1 FROM public.daily_tasks WHERE plan_id=p_plan_id FOR SHARE;
  SELECT jsonb_build_object('contractVersion',1,'tasks',coalesce(jsonb_agg(jsonb_build_object(
    'taskId',id,'startPlanned',start_planned,'endPlanned',end_planned,'zoneId',zone_id,'spaceId',space_id,
    'locationLabel',location_label,'durationOverride',duration_override,'camerasOverride',cameras_override,
    'assignedResourceIds',coalesce(assigned_resource_ids,'[]'::jsonb)) ORDER BY id),'[]'::jsonb))
    INTO current_snapshot FROM public.daily_tasks WHERE plan_id=p_plan_id;
  IF current_snapshot IS DISTINCT FROM p_snapshot THEN RAISE EXCEPTION 'STALE_DRAFT'; END IF;
  SELECT id INTO parent_id FROM public.plan_config_revisions WHERE plan_id=p_plan_id ORDER BY created_at DESC,id DESC LIMIT 1;
  IF parent_id IS NOT NULL AND EXISTS(SELECT 1 FROM public.plan_config_revisions WHERE id=parent_id AND fingerprint=p_identity->>'configurationFingerprint') THEN revision_id:=parent_id;
  ELSE
    INSERT INTO public.plan_config_revisions(plan_id,parent_revision_id,source,fingerprint,identity_json,replay_snapshot_json,created_by)
    VALUES(p_plan_id,parent_id,'ASSISTED_BOOTSTRAP',p_identity->>'configurationFingerprint',p_identity,p_replay,p_user_id) RETURNING id INTO revision_id;
  END IF;
  INSERT INTO public.assisted_planning_sessions(plan_id,status,current_config_revision_id,draft_scope_json,draft_snapshot_json,draft_fingerprint)
    VALUES(p_plan_id,'ACTIVE',revision_id,'{}',p_snapshot,p_fingerprint) RETURNING id INTO s.id;
  INSERT INTO public.assisted_planning_stages(session_id,plan_id,ordinal,parent_stage_id,scope_json,scope_task_ids_json,include_prerequisites,config_revision_id,proposal_run_id,snapshot_json,snapshot_fingerprint,validation_summary_json,accepted_by,accepted_at)
    VALUES(s.id,p_plan_id,0,NULL,'{}','[]',false,revision_id,NULL,p_snapshot,p_fingerprint,'{"hardCount":0,"requiredCount":0,"preferredCount":0,"bootstrap":true}',p_user_id,now()) RETURNING id INTO stage_id;
  UPDATE public.assisted_planning_sessions SET active_stage_id=stage_id,draft_base_stage_id=stage_id WHERE id=s.id;
  RETURN s.id;
END $$;
REVOKE ALL ON FUNCTION public.assisted_bootstrap_session(integer,uuid,jsonb,jsonb,jsonb,text) FROM PUBLIC,anon,authenticated,service_role;
GRANT EXECUTE ON FUNCTION public.assisted_bootstrap_session(integer,uuid,jsonb,jsonb,jsonb,text) TO service_role;
CREATE OR REPLACE FUNCTION public.assisted_patch_draft(p_plan_id integer,p_expected_fingerprint text,p_expected_base bigint,p_snapshot jsonb,p_fingerprint text)
RETURNS bigint LANGUAGE plpgsql SECURITY INVOKER SET search_path='' AS $$
DECLARE s public.assisted_planning_sessions%rowtype; changed_ids jsonb; forward_rows jsonb; inverse_rows jsonb; trace jsonb;
BEGIN
 SELECT * INTO s FROM public.assisted_planning_sessions WHERE plan_id=p_plan_id AND status='ACTIVE' FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'SESSION_NOT_FOUND'; END IF;
 IF s.draft_base_stage_id IS DISTINCT FROM p_expected_base THEN RAISE EXCEPTION 'STALE_BASE_STAGE'; END IF;
 IF s.draft_fingerprint<>p_expected_fingerprint THEN RAISE EXCEPTION 'STALE_DRAFT'; END IF;
 IF jsonb_typeof(p_snapshot->'tasks') IS DISTINCT FROM 'array' OR
   (SELECT array_agg((x->>'taskId')::integer ORDER BY (x->>'taskId')::integer) FROM jsonb_array_elements(p_snapshot->'tasks') x)
   IS DISTINCT FROM
   (SELECT array_agg((x->>'taskId')::integer ORDER BY (x->>'taskId')::integer) FROM jsonb_array_elements(s.draft_snapshot_json->'tasks') x)
 THEN RAISE EXCEPTION 'TASK_SET_MISMATCH'; END IF;
 SELECT coalesce(jsonb_agg((next->>'taskId')::integer ORDER BY (next->>'taskId')::integer),'[]'::jsonb),
        coalesce(jsonb_agg(next ORDER BY (next->>'taskId')::integer),'[]'::jsonb),
        coalesce(jsonb_agg(previous ORDER BY (previous->>'taskId')::integer),'[]'::jsonb)
 INTO changed_ids,forward_rows,inverse_rows
 FROM jsonb_array_elements(p_snapshot->'tasks') next
 JOIN jsonb_array_elements(s.draft_snapshot_json->'tasks') previous ON previous->>'taskId'=next->>'taskId'
 WHERE next IS DISTINCT FROM previous;
 IF coalesce(p_snapshot->'planningBlocks','[]'::jsonb) IS DISTINCT FROM coalesce(s.draft_snapshot_json->'planningBlocks','[]'::jsonb) THEN
   SELECT (SELECT coalesce(jsonb_agg(DISTINCT id ORDER BY id),'[]'::jsonb) FROM (
     SELECT (id#>>'{}')::integer id FROM jsonb_array_elements(changed_ids) id
     UNION
     SELECT (member#>>'{}')::integer id FROM jsonb_array_elements(coalesce(p_snapshot->'planningBlocks','[]')) block,
       jsonb_array_elements(block->'memberTaskIds') member
     UNION
     SELECT (member#>>'{}')::integer id FROM jsonb_array_elements(coalesce(s.draft_snapshot_json->'planningBlocks','[]')) block,
       jsonb_array_elements(block->'memberTaskIds') member) members) INTO changed_ids;
 END IF;
 IF jsonb_array_length(changed_ids)=0 THEN RAISE EXCEPTION 'VALIDATION_REQUIRED'; END IF;
 IF EXISTS (SELECT 1 FROM jsonb_array_elements(p_snapshot->'tasks') next
   JOIN jsonb_array_elements(s.draft_snapshot_json->'tasks') previous ON previous->>'taskId'=next->>'taskId'
   WHERE next IS DISTINCT FROM previous AND
    (next-'startPlanned'-'endPlanned') IS DISTINCT FROM (previous-'startPlanned'-'endPlanned'))
 THEN RAISE EXCEPTION 'UNSUPPORTED_MANUAL_FIELD'; END IF;
 IF EXISTS (SELECT 1 FROM jsonb_array_elements(p_snapshot->'tasks') next
   JOIN jsonb_array_elements(s.draft_snapshot_json->'tasks') previous ON previous->>'taskId'=next->>'taskId'
   WHERE next IS DISTINCT FROM previous AND (
    ((next->'startPlanned'='null'::jsonb) IS DISTINCT FROM (next->'endPlanned'='null'::jsonb)) OR
    (next->'startPlanned'='null'::jsonb AND NOT EXISTS (
      SELECT 1 FROM public.assisted_planning_stages base_stage,
        jsonb_array_elements(base_stage.snapshot_json->'tasks') base_task
      WHERE base_stage.id=s.draft_base_stage_id AND base_task->>'taskId'=next->>'taskId'
        AND base_task->'startPlanned'='null'::jsonb AND base_task->'endPlanned'='null'::jsonb)) OR
    (next->'startPlanned'<>'null'::jsonb AND ((next->>'endPlanned')::time-(next->>'startPlanned')::time IS DISTINCT FROM
      (previous->>'endPlanned')::time-(previous->>'startPlanned')::time))))
 THEN RAISE EXCEPTION 'INVALID_MANUAL_DURATION'; END IF;
 IF EXISTS (SELECT 1 FROM jsonb_array_elements(changed_ids) x JOIN public.daily_tasks t ON t.id=(x#>>'{}')::integer
   WHERE t.plan_id=p_plan_id AND t.status NOT IN ('pending','interrupted')) THEN RAISE EXCEPTION 'IMMUTABLE_TASK'; END IF;
 trace:=coalesce(s.draft_scope_json,'{}'::jsonb);
 trace:=trace || jsonb_build_object('editKind','MANUAL','originProposalRunId',coalesce(trace->'originProposalRunId',trace->'proposalRunId'),
   'originalScope',coalesce(trace->'originalScope',trace-'proposalRunId'-'editLedger'-'redoLedger'),
   'manualTouchedTaskIds',(SELECT coalesce(jsonb_agg(DISTINCT id ORDER BY id),'[]'::jsonb) FROM
      (SELECT (x#>>'{}')::integer id FROM jsonb_array_elements(coalesce(trace->'manualTouchedTaskIds','[]')) x
       UNION SELECT (x#>>'{}')::integer FROM jsonb_array_elements(changed_ids) x) touched),
   'editLedger',coalesce(trace->'editLedger','[]') || jsonb_build_array(jsonb_build_object(
     'beforeFingerprint',s.draft_fingerprint,'afterFingerprint',p_fingerprint,'forward',forward_rows,'inverse',inverse_rows,
     'forwardBlocks',coalesce(p_snapshot->'planningBlocks','[]'::jsonb),'inverseBlocks',coalesce(s.draft_snapshot_json->'planningBlocks','[]'::jsonb),
     'forwardHasBlocks',p_snapshot ? 'planningBlocks','inverseHasBlocks',s.draft_snapshot_json ? 'planningBlocks')),
   'redoLedger','[]'::jsonb)-'proposalRunId';
 UPDATE public.assisted_planning_sessions SET draft_snapshot_json=p_snapshot,draft_fingerprint=p_fingerprint,
   draft_scope_json=trace,draft_validation_id=NULL,updated_at=now() WHERE id=s.id;
 RETURN s.id;
END $$;
REVOKE ALL ON FUNCTION public.assisted_patch_draft(integer,text,bigint,jsonb,text) FROM PUBLIC,anon,authenticated,service_role;
GRANT EXECUTE ON FUNCTION public.assisted_patch_draft(integer,text,bigint,jsonb,text) TO service_role;
CREATE OR REPLACE FUNCTION public.assisted_accept_stage(p_plan_id integer,p_user_id uuid,p_expected_fingerprint text,p_expected_base bigint,p_confirmation text DEFAULT 'NONE')
RETURNS bigint LANGUAGE plpgsql SECURITY INVOKER SET search_path='' AS $$
DECLARE s public.assisted_planning_sessions%rowtype; v public.planning_stage_validations%rowtype; new_id bigint; next_ordinal integer; item jsonb; task_item jsonb;
BEGIN
 IF p_confirmation NOT IN ('NONE','REQUIRED_DEVIATIONS','HARD_EXCEPTIONS') THEN RAISE EXCEPTION 'INVALID_CONFIRMATION'; END IF;
 SELECT * INTO s FROM public.assisted_planning_sessions WHERE plan_id=p_plan_id AND status='ACTIVE' FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'SESSION_NOT_FOUND'; END IF;
 IF s.draft_base_stage_id IS DISTINCT FROM p_expected_base THEN RAISE EXCEPTION 'STALE_BASE_STAGE'; END IF;
 IF s.draft_fingerprint<>p_expected_fingerprint THEN RAISE EXCEPTION 'STALE_DRAFT'; END IF;
 SELECT * INTO v FROM public.planning_stage_validations WHERE id=s.draft_validation_id AND session_id=s.id AND plan_id=p_plan_id FOR SHARE;
 IF NOT FOUND OR v.draft_fingerprint<>s.draft_fingerprint OR v.config_revision_id<>s.current_config_revision_id OR v.base_stage_id IS DISTINCT FROM s.draft_base_stage_id THEN RAISE EXCEPTION 'STALE_VALIDATION'; END IF;
 IF coalesce((v.report_json->>'newHardCount')::integer,v.hard_count)>0 AND p_confirmation<>'HARD_EXCEPTIONS' THEN RAISE EXCEPTION 'HARD_CONFIRMATION_REQUIRED'; END IF;
 IF coalesce((v.report_json->>'newRequiredCount')::integer,v.required_count)>0 AND p_confirmation NOT IN ('REQUIRED_DEVIATIONS','HARD_EXCEPTIONS') THEN RAISE EXCEPTION 'REQUIRED_CONFIRMATION_REQUIRED'; END IF;
 IF (SELECT coalesce(array_agg((x->>'taskId')::integer ORDER BY (x->>'taskId')::integer),'{}') FROM jsonb_array_elements(s.draft_snapshot_json->'tasks') x)
    IS DISTINCT FROM (SELECT coalesce(array_agg(id ORDER BY id),'{}') FROM public.daily_tasks WHERE plan_id=p_plan_id)
 THEN RAISE EXCEPTION 'TASK_SET_MISMATCH'; END IF;
 FOR task_item IN SELECT value FROM jsonb_array_elements(s.draft_snapshot_json->'tasks') LOOP
   UPDATE public.daily_tasks SET start_planned=task_item->>'startPlanned',end_planned=task_item->>'endPlanned',zone_id=(task_item->>'zoneId')::integer,
     space_id=(task_item->>'spaceId')::integer,location_label=task_item->>'locationLabel',duration_override=(task_item->>'durationOverride')::integer,
     cameras_override=(task_item->>'camerasOverride')::integer,
     assigned_resource_ids=CASE WHEN task_item ? 'assignedResourceIds' THEN task_item->'assignedResourceIds' ELSE assigned_resource_ids END
   WHERE plan_id=p_plan_id AND id=(task_item->>'taskId')::integer;
 END LOOP;
 WITH RECURSIVE obsolete AS (SELECT id FROM public.assisted_planning_stages WHERE session_id=s.id AND parent_stage_id=s.draft_base_stage_id AND archived_at IS NULL UNION ALL SELECT child.id FROM public.assisted_planning_stages child JOIN obsolete parent ON child.parent_stage_id=parent.id WHERE child.session_id=s.id AND child.archived_at IS NULL)
 UPDATE public.assisted_planning_stages SET archived_at=now() WHERE id IN (SELECT id FROM obsolete);
 SELECT coalesce(max(ordinal),-1)+1 INTO next_ordinal FROM public.assisted_planning_stages WHERE session_id=s.id;
 INSERT INTO public.assisted_planning_stages(session_id,plan_id,ordinal,parent_stage_id,scope_json,scope_task_ids_json,include_prerequisites,config_revision_id,proposal_run_id,snapshot_json,snapshot_fingerprint,validation_summary_json,accepted_by,accepted_at)
 VALUES(s.id,p_plan_id,next_ordinal,s.draft_base_stage_id,s.draft_scope_json,
   coalesce(s.draft_scope_json->'resolvedTaskIds',s.draft_scope_json->'originalScope'->'resolvedTaskIds','[]'::jsonb),
   coalesce((s.draft_scope_json->>'includePrerequisites')::boolean,(s.draft_scope_json->'originalScope'->>'includePrerequisites')::boolean,false),
   s.current_config_revision_id,
   CASE WHEN s.draft_scope_json->>'editKind' IS DISTINCT FROM 'MANUAL' THEN (s.draft_scope_json->>'proposalRunId')::bigint ELSE NULL END,
   s.draft_snapshot_json,s.draft_fingerprint,
   jsonb_build_object('hardValid',v.hard_count=0,'hardCount',v.hard_count,'requiredCount',v.required_count,'preferredCount',v.preferred_count,'validationId',v.id,'report',v.report_json),p_user_id,now()) RETURNING id INTO new_id;
 FOR item IN SELECT value FROM jsonb_array_elements(v.report_json->'violations') WHERE value->>'severity' IN ('HARD','REQUIRED') AND value->>'inheritedAcceptedExceptionId' IS NULL LOOP
   INSERT INTO public.planning_accepted_exceptions(plan_id,stage_id,severity,rule_code,violation_key,config_revision_id,snapshot_fingerprint,affected_task_ids_json,affected_resource_ids_json,affected_space_ids_json,details_json,status,accepted_by,accepted_at)
   VALUES(p_plan_id,new_id,item->>'severity',item->>'ruleCode',item->>'violationKey',s.current_config_revision_id,s.draft_fingerprint,item->'affectedTaskIds',coalesce(item->'affectedResourceIds','[]'),coalesce(item->'affectedSpaceIds','[]'),coalesce(item->'details','{}'),'ACTIVE',p_user_id,now());
 END LOOP;
 WITH RECURSIVE lineage AS (
   SELECT id,parent_stage_id,snapshot_json FROM public.assisted_planning_stages WHERE id=s.draft_base_stage_id AND session_id=s.id
   UNION ALL SELECT parent.id,parent.parent_stage_id,parent.snapshot_json FROM public.assisted_planning_stages parent JOIN lineage child ON parent.id=child.parent_stage_id WHERE parent.session_id=s.id
 ) UPDATE public.planning_accepted_exceptions exception SET status='SUPERSEDED',resolved_at=now()
 FROM lineage origin WHERE exception.stage_id=origin.id AND exception.status='ACTIVE'
   AND EXISTS(SELECT 1 FROM jsonb_array_elements(exception.affected_task_ids_json) affected WHERE
     (SELECT task FROM jsonb_array_elements(origin.snapshot_json->'tasks') task WHERE task->>'taskId'=affected#>>'{}') IS DISTINCT FROM
     (SELECT task FROM jsonb_array_elements(s.draft_snapshot_json->'tasks') task WHERE task->>'taskId'=affected#>>'{}'));
 UPDATE public.assisted_planning_sessions SET active_stage_id=new_id,draft_base_stage_id=new_id,draft_scope_json='{}',draft_validation_id=NULL,updated_at=now() WHERE id=s.id;
 RETURN new_id;
EXCEPTION WHEN unique_violation THEN RAISE EXCEPTION 'CONCURRENT_ACCEPT'; END $$;
REVOKE ALL ON FUNCTION public.assisted_accept_stage(integer,uuid,text,bigint,text) FROM PUBLIC,anon,authenticated,service_role;
GRANT EXECUTE ON FUNCTION public.assisted_accept_stage(integer,uuid,text,bigint,text) TO service_role;
CREATE OR REPLACE FUNCTION public.assisted_move_stage(p_plan_id integer,p_target bigint,p_redo boolean)
RETURNS bigint LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE s assisted_planning_sessions%rowtype; target assisted_planning_stages%rowtype; cursor_id bigint;
BEGIN
 SELECT * INTO s FROM assisted_planning_sessions WHERE plan_id=p_plan_id AND status='ACTIVE' FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'SESSION_NOT_FOUND'; END IF;
 IF p_redo THEN
   SELECT * INTO target FROM assisted_planning_stages WHERE session_id=s.id AND plan_id=p_plan_id AND parent_stage_id=s.active_stage_id AND archived_at IS NULL;
   IF NOT FOUND THEN RAISE EXCEPTION 'NO_REDO_AVAILABLE'; END IF;
 ELSE
   SELECT * INTO target FROM assisted_planning_stages WHERE id=p_target AND session_id=s.id AND plan_id=p_plan_id;
   IF NOT FOUND THEN RAISE EXCEPTION 'INVALID_STAGE_TARGET'; END IF;
   cursor_id:=s.active_stage_id;
   LOOP EXIT WHEN cursor_id=target.id; SELECT parent_stage_id INTO cursor_id FROM assisted_planning_stages WHERE id=cursor_id AND session_id=s.id; IF cursor_id IS NULL THEN RAISE EXCEPTION 'INVALID_STAGE_TARGET'; END IF; END LOOP;
 END IF;
 PERFORM assisted_apply_snapshot(p_plan_id,target.snapshot_json);
 UPDATE assisted_planning_sessions SET active_stage_id=target.id,draft_base_stage_id=target.id,draft_snapshot_json=target.snapshot_json,
 draft_fingerprint=target.snapshot_fingerprint,draft_scope_json='{}',draft_validation_id=NULL,updated_at=now() WHERE id=s.id;
 RETURN target.id;
END $$;
REVOKE ALL ON FUNCTION public.assisted_move_stage(integer,bigint,boolean) FROM PUBLIC,anon,authenticated,service_role;
GRANT EXECUTE ON FUNCTION public.assisted_move_stage(integer,bigint,boolean) TO service_role;
CREATE OR REPLACE FUNCTION public.assisted_finish_proposal(p_plan_id integer,p_run_id bigint,p_result jsonb)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
BEGIN
 IF jsonb_typeof(p_result)<>'object' OR (p_result->>'contractVersion')::integer<>1 THEN RAISE EXCEPTION 'RUN_RESULT_INVALID'; END IF;
 UPDATE planning_runs SET status='success',assisted_result_json=p_result,
   result_fingerprint=encode(extensions.digest(convert_to(p_result::text,'UTF8'),'sha256'),'hex'),finished_at=now(),updated_at=now()
 WHERE id=p_run_id AND plan_id=p_plan_id AND execution_kind='ASSISTED_SCOPE' AND status='running';
 IF NOT FOUND THEN RAISE EXCEPTION 'RUN_NOT_READY'; END IF;
END $$;
REVOKE ALL ON FUNCTION public.assisted_finish_proposal(integer,bigint,jsonb) FROM PUBLIC,anon,authenticated,service_role;
GRANT EXECUTE ON FUNCTION public.assisted_finish_proposal(integer,bigint,jsonb) TO service_role;
CREATE OR REPLACE FUNCTION public.assisted_apply_proposal(p_plan_id integer,p_run_id bigint,p_expected_fingerprint text,p_expected_base bigint)
RETURNS bigint LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
DECLARE s assisted_planning_sessions%rowtype; r planning_runs%rowtype; result jsonb; proposed jsonb; proposed_fingerprint text; trace jsonb;
BEGIN
 SELECT * INTO s FROM assisted_planning_sessions WHERE plan_id=p_plan_id AND status='ACTIVE' FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'SESSION_NOT_FOUND'; END IF;
 SELECT * INTO r FROM planning_runs WHERE id=p_run_id AND plan_id=p_plan_id AND execution_kind='ASSISTED_SCOPE';
 IF NOT FOUND THEN RAISE EXCEPTION 'RUN_NOT_FOUND'; END IF;
 IF r.assisted_session_id<>s.id THEN RAISE EXCEPTION 'RUN_SESSION_MISMATCH'; END IF;
 IF r.status<>'success' OR r.assisted_result_json IS NULL THEN RAISE EXCEPTION 'RUN_NOT_READY'; END IF;
 result:=r.assisted_result_json;
 IF result->>'outcome'<>'PROPOSAL' THEN RAISE EXCEPTION 'RUN_HAS_NO_PROPOSAL'; END IF;
 IF r.base_stage_id IS DISTINCT FROM p_expected_base OR s.draft_base_stage_id IS DISTINCT FROM r.base_stage_id THEN RAISE EXCEPTION 'STALE_BASE_STAGE'; END IF;
 IF s.draft_fingerprint<>p_expected_fingerprint OR s.draft_fingerprint<>r.source_draft_fingerprint THEN RAISE EXCEPTION 'STALE_DRAFT'; END IF;
 IF s.current_config_revision_id<>r.config_revision_id THEN RAISE EXCEPTION 'STALE_CONFIG_REVISION'; END IF;
 IF r.result_fingerprint IS NULL OR r.result_fingerprint<>encode(extensions.digest(convert_to(result::text,'UTF8'),'sha256'),'hex') THEN RAISE EXCEPTION 'RUN_RESULT_INVALID'; END IF;
 proposed:=result->'proposedDraftSnapshot'; proposed_fingerprint:=result->>'proposedDraftFingerprint';
 IF jsonb_typeof(proposed)<>'object' OR proposed->>'contractVersion'<>'1' OR jsonb_typeof(proposed->'tasks')<>'array'
   OR proposed_fingerprint !~ '^[0-9a-f]{64}$' OR jsonb_typeof(result->'proposal')<>'array' THEN RAISE EXCEPTION 'RUN_RESULT_INVALID'; END IF;
 IF (SELECT count(*) FROM jsonb_array_elements(proposed->'tasks'))<>(SELECT count(DISTINCT (item->>'taskId')::integer) FROM jsonb_array_elements(proposed->'tasks') item)
   OR (SELECT coalesce(array_agg((item->>'taskId')::integer ORDER BY (item->>'taskId')::integer),'{}') FROM jsonb_array_elements(proposed->'tasks') item)
      IS DISTINCT FROM
      (SELECT coalesce(array_agg((item->>'taskId')::integer ORDER BY (item->>'taskId')::integer),'{}') FROM jsonb_array_elements(s.draft_snapshot_json->'tasks') item)
   OR EXISTS (SELECT 1 FROM jsonb_array_elements(result->'proposal') item WHERE NOT (r.scope_task_ids_json @> jsonb_build_array((item->>'taskId')::integer)))
 THEN RAISE EXCEPTION 'RUN_RESULT_INVALID'; END IF;
 trace:=jsonb_build_object('contractVersion',1,'selector',r.scope_json->'selector','metadata',r.scope_json->'metadata','resolvedTaskIds',r.scope_task_ids_json,'includePrerequisites',r.include_prerequisites,'proposalRunId',r.id);
 UPDATE assisted_planning_sessions SET draft_snapshot_json=proposed,draft_fingerprint=proposed_fingerprint,draft_scope_json=trace,draft_validation_id=NULL,updated_at=now() WHERE id=s.id;
 RETURN s.id;
END $$;
REVOKE ALL ON FUNCTION public.assisted_apply_proposal(integer,bigint,text,bigint) FROM PUBLIC,anon,authenticated,service_role;
GRANT EXECUTE ON FUNCTION public.assisted_apply_proposal(integer,bigint,text,bigint) TO service_role;
CREATE OR REPLACE FUNCTION public.assisted_record_proposal_clean_validation(
  p_plan_id integer, p_expected_fingerprint text, p_expected_base bigint,
  p_expected_config bigint
) RETURNS bigint LANGUAGE plpgsql SECURITY INVOKER SET search_path='' AS $$
DECLARE
  s public.assisted_planning_sessions%rowtype;
  r public.planning_runs%rowtype;
  result jsonb;
  evidence jsonb;
  proposal_run_id bigint;
  validation_id bigint;
  report jsonb;
BEGIN
  SELECT * INTO s FROM public.assisted_planning_sessions
    WHERE plan_id=p_plan_id AND status='ACTIVE' FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'SESSION_NOT_FOUND'; END IF;
  IF s.draft_fingerprint<>p_expected_fingerprint THEN RAISE EXCEPTION 'STALE_DRAFT'; END IF;
  IF s.draft_base_stage_id IS DISTINCT FROM p_expected_base THEN RAISE EXCEPTION 'STALE_BASE_STAGE'; END IF;
  IF s.current_config_revision_id<>p_expected_config THEN RAISE EXCEPTION 'STALE_CONFIG_REVISION'; END IF;

  IF jsonb_typeof(s.draft_scope_json) IS DISTINCT FROM 'object'
    OR coalesce(s.draft_scope_json->>'proposalRunId','') !~ '^[1-9][0-9]*$'
    OR jsonb_typeof(s.draft_scope_json->'resolvedTaskIds') IS DISTINCT FROM 'array'
    OR jsonb_typeof(s.draft_scope_json->'includePrerequisites') IS DISTINCT FROM 'boolean'
  THEN RAISE EXCEPTION 'VALIDATION_REQUIRED'; END IF;
  proposal_run_id := (s.draft_scope_json->>'proposalRunId')::bigint;

  SELECT * INTO r FROM public.planning_runs WHERE id=proposal_run_id;
  IF NOT FOUND OR r.plan_id<>p_plan_id OR r.execution_kind<>'ASSISTED_SCOPE'
    OR r.assisted_session_id<>s.id OR r.base_stage_id IS DISTINCT FROM s.draft_base_stage_id
    OR r.config_revision_id<>s.current_config_revision_id OR r.status<>'success'
    OR r.assisted_result_json IS NULL
  THEN RAISE EXCEPTION 'VALIDATION_REQUIRED'; END IF;

  result := r.assisted_result_json;
  evidence := result->'evidence';
  IF r.result_fingerprint IS NULL
    OR r.result_fingerprint<>encode(extensions.digest(convert_to(result::text,'UTF8'),'sha256'),'hex')
    OR result->>'contractVersion' IS DISTINCT FROM '1' OR result->>'outcome' IS DISTINCT FROM 'PROPOSAL'
    OR jsonb_typeof(result->'proposal') IS DISTINCT FROM 'array'
    OR jsonb_array_length(result->'proposal')=0
    OR jsonb_typeof(result->'proposedDraftSnapshot') IS DISTINCT FROM 'object'
    OR result->'proposedDraftSnapshot' IS DISTINCT FROM s.draft_snapshot_json
    OR result->>'proposedDraftFingerprint' IS DISTINCT FROM s.draft_fingerprint
    OR result->'scopeTaskIds' IS DISTINCT FROM r.scope_task_ids_json
    OR result->'scopeTaskIds' IS DISTINCT FROM s.draft_scope_json->'resolvedTaskIds'
    OR result->'includePrerequisites' IS DISTINCT FROM to_jsonb(r.include_prerequisites)
    OR result->'includePrerequisites' IS DISTINCT FROM s.draft_scope_json->'includePrerequisites'
    OR EXISTS (SELECT 1 FROM jsonb_array_elements(result->'proposal') item
      WHERE jsonb_typeof(item) IS DISTINCT FROM 'object' OR coalesce(item->>'taskId','') !~ '^[1-9][0-9]*$'
      OR coalesce(item->>'startPlanned','')='' OR coalesce(item->>'endPlanned','')=''
      OR NOT EXISTS (SELECT 1 FROM jsonb_array_elements(r.scope_task_ids_json) scope_id
        WHERE scope_id #>> '{}' = item->>'taskId'))
    OR (SELECT count(*) FROM jsonb_array_elements(result->'proposal'))
      <> (SELECT count(DISTINCT item->>'taskId') FROM jsonb_array_elements(result->'proposal') item)
  THEN RAISE EXCEPTION 'RUN_RESULT_INVALID'; END IF;

  IF jsonb_typeof(evidence) IS DISTINCT FROM 'object'
    OR evidence->>'proposalCount' IS DISTINCT FROM '1'
    OR evidence->>'completeForScope' IS DISTINCT FROM 'true'
    OR evidence->>'protectedPlacementsPreserved' IS DISTINCT FROM 'true'
  THEN RAISE EXCEPTION 'RUN_RESULT_INVALID'; END IF;
  IF evidence->>'hardValid' IS DISTINCT FROM 'true' OR evidence->>'requiredValid' IS DISTINCT FROM 'true'
  THEN RAISE EXCEPTION 'VALIDATION_NOT_ACCEPTABLE'; END IF;

  report := jsonb_build_object(
    'mode','PROPOSAL_CERTIFIED_CLEAN_V1', 'proposalRunId',proposal_run_id,
    'scopeTaskIds',r.scope_task_ids_json, 'includePrerequisites',r.include_prerequisites,
    'hardAssessment','CLEAN', 'requiredAssessment','CLEAN',
    'preferredAssessment','NOT_CLASSIFIED');
  INSERT INTO public.planning_stage_validations(plan_id,session_id,base_stage_id,draft_fingerprint,
    config_revision_id,hard_count,required_count,preferred_count,report_json)
  VALUES(p_plan_id,s.id,s.draft_base_stage_id,s.draft_fingerprint,s.current_config_revision_id,
    0,0,0,report) RETURNING id INTO validation_id;
  UPDATE public.assisted_planning_sessions SET draft_validation_id=validation_id,updated_at=now() WHERE id=s.id;
  RETURN validation_id;
END $$;
REVOKE ALL ON FUNCTION public.assisted_record_proposal_clean_validation(integer,text,bigint,bigint) FROM PUBLIC,anon,authenticated,service_role;
GRANT EXECUTE ON FUNCTION public.assisted_record_proposal_clean_validation(integer,text,bigint,bigint) TO service_role;
CREATE OR REPLACE FUNCTION public.assisted_move_draft_edit(p_plan_id integer,p_expected_fingerprint text,p_expected_base bigint,p_redo boolean)
RETURNS bigint LANGUAGE plpgsql SECURITY INVOKER SET search_path='' AS $$
DECLARE s public.assisted_planning_sessions%rowtype; trace jsonb; source jsonb; operation jsonb; next_snapshot jsonb; next_fingerprint text;
BEGIN
 SELECT * INTO s FROM public.assisted_planning_sessions WHERE plan_id=p_plan_id AND status='ACTIVE' FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'SESSION_NOT_FOUND'; END IF;
 IF s.draft_base_stage_id IS DISTINCT FROM p_expected_base THEN RAISE EXCEPTION 'STALE_BASE_STAGE'; END IF;
 IF s.draft_fingerprint<>p_expected_fingerprint THEN RAISE EXCEPTION 'STALE_DRAFT'; END IF;
 trace:=coalesce(s.draft_scope_json,'{}'::jsonb); source:=coalesce(trace->(CASE WHEN p_redo THEN 'redoLedger' ELSE 'editLedger' END),'[]'::jsonb);
 IF jsonb_array_length(source)=0 THEN RAISE EXCEPTION USING MESSAGE=CASE WHEN p_redo THEN 'NO_REDO_AVAILABLE' ELSE 'NO_UNDO_AVAILABLE' END; END IF;
 operation:=source->(jsonb_array_length(source)-1); next_snapshot:=s.draft_snapshot_json;
 IF jsonb_typeof(operation) IS DISTINCT FROM 'object'
   OR coalesce(operation->>'beforeFingerprint','') !~ '^[0-9a-f]{64}$'
   OR coalesce(operation->>'afterFingerprint','') !~ '^[0-9a-f]{64}$'
   OR jsonb_typeof(operation->'forward') IS DISTINCT FROM 'array'
   OR jsonb_typeof(operation->'inverse') IS DISTINCT FROM 'array'
   OR s.draft_fingerprint IS DISTINCT FROM operation->>(CASE WHEN p_redo THEN 'beforeFingerprint' ELSE 'afterFingerprint' END)
 THEN RAISE EXCEPTION 'CORRUPT_EDIT_LEDGER'; END IF;
 SELECT jsonb_set(next_snapshot,'{tasks}',jsonb_agg(coalesce(patch.row,current.row) ORDER BY (current.row->>'taskId')::integer)) INTO next_snapshot
 FROM jsonb_array_elements(next_snapshot->'tasks') current(row)
 LEFT JOIN jsonb_array_elements(operation->(CASE WHEN p_redo THEN 'forward' ELSE 'inverse' END)) patch(row)
   ON patch.row->>'taskId'=current.row->>'taskId';
 IF operation ? (CASE WHEN p_redo THEN 'forwardHasBlocks' ELSE 'inverseHasBlocks' END) THEN
   IF (operation->>(CASE WHEN p_redo THEN 'forwardHasBlocks' ELSE 'inverseHasBlocks' END))::boolean THEN
     next_snapshot:=jsonb_set(next_snapshot,'{planningBlocks}',operation->(CASE WHEN p_redo THEN 'forwardBlocks' ELSE 'inverseBlocks' END),true);
   ELSE next_snapshot:=next_snapshot-'planningBlocks'; END IF;
 END IF;
 next_fingerprint:=operation->>(CASE WHEN p_redo THEN 'afterFingerprint' ELSE 'beforeFingerprint' END);
 trace:=jsonb_set(trace,ARRAY[CASE WHEN p_redo THEN 'redoLedger' ELSE 'editLedger' END],source-(jsonb_array_length(source)-1));
 trace:=jsonb_set(trace,ARRAY[CASE WHEN p_redo THEN 'editLedger' ELSE 'redoLedger' END],
   coalesce(trace->(CASE WHEN p_redo THEN 'editLedger' ELSE 'redoLedger' END),'[]'::jsonb)||jsonb_build_array(operation));
 UPDATE public.assisted_planning_sessions SET draft_snapshot_json=next_snapshot,draft_fingerprint=next_fingerprint,
   draft_scope_json=trace,draft_validation_id=NULL,updated_at=now() WHERE id=s.id;
 RETURN s.id;
END $$;
REVOKE ALL ON FUNCTION public.assisted_move_draft_edit(integer,text,bigint,boolean) FROM PUBLIC,anon,authenticated,service_role;
GRANT EXECUTE ON FUNCTION public.assisted_move_draft_edit(integer,text,bigint,boolean) TO service_role;
CREATE OR REPLACE FUNCTION public.assisted_record_manual_clean_validation(p_plan_id integer,p_expected_fingerprint text,p_expected_base bigint,p_expected_config bigint,p_report jsonb)
RETURNS bigint LANGUAGE plpgsql SECURITY INVOKER SET search_path='' AS $$
DECLARE s public.assisted_planning_sessions%rowtype; validation_id bigint;
BEGIN
 SELECT * INTO s FROM public.assisted_planning_sessions WHERE plan_id=p_plan_id AND status='ACTIVE' FOR UPDATE;
 IF NOT FOUND THEN RAISE EXCEPTION 'SESSION_NOT_FOUND'; END IF;
 IF s.draft_fingerprint<>p_expected_fingerprint THEN RAISE EXCEPTION 'STALE_DRAFT'; END IF;
 IF s.draft_base_stage_id IS DISTINCT FROM p_expected_base THEN RAISE EXCEPTION 'STALE_BASE_STAGE'; END IF;
 IF s.current_config_revision_id<>p_expected_config THEN RAISE EXCEPTION 'STALE_CONFIG_REVISION'; END IF;
 IF s.draft_scope_json->>'editKind' IS DISTINCT FROM 'MANUAL' THEN RAISE EXCEPTION 'VALIDATION_REQUIRED'; END IF;
 IF p_report->>'mode' IS DISTINCT FROM 'MANUAL_DELTA_CLEAN_V1' OR p_report->>'completeForScope' IS DISTINCT FROM 'true'
  OR p_report->>'protectedPlacementsPreserved' IS DISTINCT FROM 'true' OR p_report->>'hardValid' IS DISTINCT FROM 'true'
  OR p_report->>'requiredValid' IS DISTINCT FROM 'true' OR p_report->>'futureFullDayFeasibility' IS DISTINCT FROM 'NOT_CERTIFIED'
 THEN RAISE EXCEPTION 'VALIDATION_NOT_ACCEPTABLE'; END IF;
 INSERT INTO public.planning_stage_validations(plan_id,session_id,base_stage_id,draft_fingerprint,config_revision_id,hard_count,required_count,preferred_count,report_json)
 VALUES(p_plan_id,s.id,s.draft_base_stage_id,s.draft_fingerprint,s.current_config_revision_id,0,0,0,p_report) RETURNING id INTO validation_id;
 UPDATE public.assisted_planning_sessions SET draft_validation_id=validation_id,updated_at=now() WHERE id=s.id;
 RETURN validation_id;
END $$;
REVOKE ALL ON FUNCTION public.assisted_record_manual_clean_validation(integer,text,bigint,bigint,jsonb) FROM PUBLIC,anon,authenticated,service_role;
GRANT EXECUTE ON FUNCTION public.assisted_record_manual_clean_validation(integer,text,bigint,bigint,jsonb) TO service_role;
CREATE OR REPLACE FUNCTION public.assisted_record_stage_validation(
  p_plan_id integer,p_expected_fingerprint text,p_expected_base bigint,p_expected_config bigint,p_report jsonb
) RETURNS bigint LANGUAGE plpgsql SECURITY INVOKER SET search_path='' AS $$
DECLARE s public.assisted_planning_sessions%rowtype; validation_id bigint;
BEGIN
  SELECT * INTO s FROM public.assisted_planning_sessions WHERE plan_id=p_plan_id AND status='ACTIVE' FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'SESSION_NOT_FOUND'; END IF;
  IF s.draft_fingerprint<>p_expected_fingerprint THEN RAISE EXCEPTION 'STALE_DRAFT'; END IF;
  IF s.draft_base_stage_id IS DISTINCT FROM p_expected_base THEN RAISE EXCEPTION 'STALE_BASE_STAGE'; END IF;
  IF s.current_config_revision_id<>p_expected_config THEN RAISE EXCEPTION 'STALE_CONFIG_REVISION'; END IF;
  IF p_report->>'contractVersion'<>'1' OR jsonb_typeof(p_report->'violations') IS DISTINCT FROM 'array'
    OR coalesce(p_report->>'hardCount','') !~ '^\d+$' OR coalesce(p_report->>'requiredCount','') !~ '^\d+$'
    OR (p_report->>'hardCount')::integer<>(SELECT count(*) FROM jsonb_array_elements(p_report->'violations') x WHERE x->>'severity'='HARD')
    OR (p_report->>'requiredCount')::integer<>(SELECT count(*) FROM jsonb_array_elements(p_report->'violations') x WHERE x->>'severity'='REQUIRED')
    OR EXISTS(SELECT 1 FROM jsonb_array_elements(p_report->'violations') x WHERE x->>'severity' NOT IN ('HARD','REQUIRED','PREFERRED') OR coalesce(x->>'ruleCode','')='' OR coalesce(x->>'violationKey','')='')
  THEN RAISE EXCEPTION 'RUN_RESULT_INVALID'; END IF;
  INSERT INTO public.planning_stage_validations(plan_id,session_id,base_stage_id,draft_fingerprint,config_revision_id,hard_count,required_count,preferred_count,report_json)
    VALUES(p_plan_id,s.id,s.draft_base_stage_id,s.draft_fingerprint,s.current_config_revision_id,
      (p_report->>'hardCount')::integer,(p_report->>'requiredCount')::integer,coalesce((p_report->>'preferredCount')::integer,0),p_report)
    RETURNING id INTO validation_id;
  UPDATE public.assisted_planning_sessions SET draft_validation_id=validation_id,updated_at=now() WHERE id=s.id;
  RETURN validation_id;
END $$;
REVOKE ALL ON FUNCTION public.assisted_record_stage_validation(integer,text,bigint,bigint,jsonb) FROM PUBLIC,anon,authenticated,service_role;
GRANT EXECUTE ON FUNCTION public.assisted_record_stage_validation(integer,text,bigint,bigint,jsonb) TO service_role;
CREATE OR REPLACE FUNCTION public.assisted_apply_config_refresh(
  p_plan_id INTEGER, p_user_id UUID, p_expected_revision BIGINT,
  p_identity JSONB, p_replay JSONB, p_diff JSONB
) RETURNS BIGINT LANGUAGE plpgsql SECURITY INVOKER SET search_path=public AS $$
DECLARE s public.assisted_planning_sessions%ROWTYPE; new_revision BIGINT; item JSONB; optimizer JSONB; affected_rows INTEGER;
BEGIN
  SELECT * INTO s FROM public.assisted_planning_sessions WHERE plan_id=p_plan_id AND status='ACTIVE' FOR UPDATE;
  IF s.id IS NULL THEN RAISE EXCEPTION 'SESSION_NOT_FOUND'; END IF;
  IF s.current_config_revision_id<>p_expected_revision THEN RAISE EXCEPTION 'STALE_CONFIG_REVISION'; END IF;
  IF p_identity->>'configurationFingerprint'=(SELECT fingerprint FROM public.plan_config_revisions WHERE id=p_expected_revision) THEN RAISE EXCEPTION 'NO_CHANGES'; END IF;
  IF jsonb_typeof(p_replay->'taskTemplateSnapshots') IS DISTINCT FROM 'array'
     OR jsonb_typeof(p_replay->'optimizerSnapshot') IS DISTINCT FROM 'object'
     OR p_identity->>'configurationFingerprint' IS NULL THEN RAISE EXCEPTION 'INVALID_REFRESH_REPLAY'; END IF;
  IF EXISTS (SELECT 1 FROM jsonb_array_elements(p_replay->'taskTemplateSnapshots') x
             GROUP BY (x->>'sourceTemplateId')::int HAVING count(*)<>1) THEN RAISE EXCEPTION 'INVALID_REFRESH_REPLAY'; END IF;

  -- Replace only the versioned daily catalogs represented by the replay. No
  -- placements, daily_tasks, stages, validations or accepted exceptions are updated.
  FOR item IN SELECT * FROM jsonb_array_elements(p_replay->'taskTemplateSnapshots') LOOP
    INSERT INTO public.plan_task_template_snapshots(plan_id,source_template_id,contract_version,source,template_name,default_duration,default_cameras,default_zone_id,default_space_id,auto_create_on_contestant_create,requires_auxiliar,requires_coach,requires_presenter,exclusive_auxiliar,has_dependency,dependency_template_ids,resource_requirements,itinerant_team_requirement,itinerant_team_id,allowed_itinerant_team_ids,setup_id,participant_margin_before_minutes,participant_margin_after_minutes)
    VALUES(p_plan_id,(item->>'sourceTemplateId')::int,2,item->>'source',item->>'templateName',(item->>'defaultDuration')::int,(item->>'defaultCameras')::int,(item->>'defaultZoneId')::int,(item->>'defaultSpaceId')::int,(item->>'autoCreateOnContestantCreate')::bool,(item->>'requiresAuxiliar')::bool,(item->>'requiresCoach')::bool,(item->>'requiresPresenter')::bool,(item->>'exclusiveAuxiliar')::bool,(item->>'hasDependency')::bool,item->'dependencyTemplateIds',NULLIF(item->'resourceRequirements','null'::jsonb),item->>'itinerantTeamRequirement',(item->>'itinerantTeamId')::int,item->'allowedItinerantTeamIds',(item->>'setupId')::int,(item->>'participantMarginBeforeMinutes')::int,(item->>'participantMarginAfterMinutes')::int)
    ON CONFLICT(plan_id,source_template_id) DO UPDATE SET source=EXCLUDED.source,template_name=EXCLUDED.template_name,default_duration=EXCLUDED.default_duration,default_cameras=EXCLUDED.default_cameras,default_zone_id=EXCLUDED.default_zone_id,default_space_id=EXCLUDED.default_space_id,auto_create_on_contestant_create=EXCLUDED.auto_create_on_contestant_create,requires_auxiliar=EXCLUDED.requires_auxiliar,requires_coach=EXCLUDED.requires_coach,requires_presenter=EXCLUDED.requires_presenter,exclusive_auxiliar=EXCLUDED.exclusive_auxiliar,has_dependency=EXCLUDED.has_dependency,dependency_template_ids=EXCLUDED.dependency_template_ids,resource_requirements=EXCLUDED.resource_requirements,itinerant_team_requirement=EXCLUDED.itinerant_team_requirement,itinerant_team_id=EXCLUDED.itinerant_team_id,allowed_itinerant_team_ids=EXCLUDED.allowed_itinerant_team_ids,setup_id=EXCLUDED.setup_id,participant_margin_before_minutes=EXCLUDED.participant_margin_before_minutes,participant_margin_after_minutes=EXCLUDED.participant_margin_after_minutes;
  END LOOP;
  optimizer:=p_replay->'optimizerSnapshot';
  UPDATE public.plan_optimizer_snapshots SET source=optimizer->>'source',editing_mode=optimizer->>'editingMode',main_zone_id=(optimizer->>'mainZoneId')::int,arrival_plan_template_snapshot_id=(optimizer#>>'{transport,arrivalPlanTemplateSnapshotId}')::bigint,departure_plan_template_snapshot_id=(optimizer#>>'{transport,departurePlanTemplateSnapshotId}')::bigint,arrival_grouping_target=(optimizer#>>'{transport,arrivalGroupingTarget}')::int,departure_grouping_target=(optimizer#>>'{transport,departureGroupingTarget}')::int,arrival_min_gap_minutes=(optimizer#>>'{transport,arrivalMinGapMinutes}')::int,departure_min_gap_minutes=(optimizer#>>'{transport,departureMinGapMinutes}')::int,van_capacity=(optimizer#>>'{transport,vanCapacity}')::int,grouping_weight=(optimizer#>>'{transport,groupingWeight}')::int,near_hard_breaks_max=(optimizer->>'nearHardBreaksMax')::int,updated_by=p_user_id,updated_at=now() WHERE plan_id=p_plan_id;
  GET DIAGNOSTICS affected_rows = ROW_COUNT;
  IF affected_rows<>1 THEN RAISE EXCEPTION 'REFRESH_REPLAY_NOT_MATERIALIZED'; END IF;
  DELETE FROM public.plan_optimizer_snapshot_heuristics h USING public.plan_optimizer_snapshots o WHERE h.snapshot_id=o.id AND o.plan_id=p_plan_id;
  INSERT INTO public.plan_optimizer_snapshot_heuristics(snapshot_id,heuristic_key,basic_level,advanced_value)
    SELECT o.id,h.key,(h.value->>'basicLevel')::int,(h.value->>'advancedValue')::int FROM public.plan_optimizer_snapshots o,jsonb_each(optimizer->'heuristics') h WHERE o.plan_id=p_plan_id;
  DELETE FROM public.plan_optimizer_snapshot_grouping_zones g USING public.plan_optimizer_snapshots o WHERE g.snapshot_id=o.id AND o.plan_id=p_plan_id;
  INSERT INTO public.plan_optimizer_snapshot_grouping_zones(snapshot_id,zone_id)
    SELECT o.id,(z#>>'{}')::int FROM public.plan_optimizer_snapshots o,jsonb_array_elements(optimizer->'groupingZoneIds') z WHERE o.plan_id=p_plan_id;
  DELETE FROM public.plan_task_template_snapshots t WHERE t.plan_id=p_plan_id AND NOT EXISTS(SELECT 1 FROM jsonb_array_elements(p_replay->'taskTemplateSnapshots') x WHERE (x->>'sourceTemplateId')::int=t.source_template_id);

  -- Do not persist a revision whose replay differs from the rows actually
  -- materialized. The transaction aborts atomically on any lossy projection.
  IF (SELECT count(*) FROM public.plan_task_template_snapshots WHERE plan_id=p_plan_id)
       <> jsonb_array_length(p_replay->'taskTemplateSnapshots')
     OR EXISTS (
       SELECT 1 FROM jsonb_array_elements(p_replay->'taskTemplateSnapshots') x
       LEFT JOIN public.plan_task_template_snapshots t ON t.plan_id=p_plan_id AND t.source_template_id=(x->>'sourceTemplateId')::int
       WHERE t.id IS NULL OR t.source IS DISTINCT FROM x->>'source'
          OR t.template_name IS DISTINCT FROM x->>'templateName'
          OR t.default_duration IS DISTINCT FROM (x->>'defaultDuration')::int
          OR t.default_cameras IS DISTINCT FROM (x->>'defaultCameras')::int
          OR t.default_zone_id IS DISTINCT FROM (x->>'defaultZoneId')::int
          OR t.default_space_id IS DISTINCT FROM (x->>'defaultSpaceId')::int
          OR t.auto_create_on_contestant_create IS DISTINCT FROM (x->>'autoCreateOnContestantCreate')::bool
          OR t.requires_auxiliar IS DISTINCT FROM (x->>'requiresAuxiliar')::bool
          OR t.requires_coach IS DISTINCT FROM (x->>'requiresCoach')::bool
          OR t.requires_presenter IS DISTINCT FROM (x->>'requiresPresenter')::bool
          OR t.exclusive_auxiliar IS DISTINCT FROM (x->>'exclusiveAuxiliar')::bool
          OR t.has_dependency IS DISTINCT FROM (x->>'hasDependency')::bool
          OR (SELECT COALESCE(jsonb_agg(v ORDER BY v::text),'[]'::jsonb) FROM jsonb_array_elements(t.dependency_template_ids) v)
             IS DISTINCT FROM (SELECT COALESCE(jsonb_agg(v ORDER BY v::text),'[]'::jsonb) FROM jsonb_array_elements(x->'dependencyTemplateIds') v)
          OR t.resource_requirements IS DISTINCT FROM NULLIF(x->'resourceRequirements','null'::jsonb)
          OR t.itinerant_team_requirement IS DISTINCT FROM x->>'itinerantTeamRequirement'
          OR t.itinerant_team_id IS DISTINCT FROM (x->>'itinerantTeamId')::int
          OR (SELECT COALESCE(jsonb_agg(v ORDER BY v::text),'[]'::jsonb) FROM jsonb_array_elements(t.allowed_itinerant_team_ids) v)
             IS DISTINCT FROM (SELECT COALESCE(jsonb_agg(v ORDER BY v::text),'[]'::jsonb) FROM jsonb_array_elements(x->'allowedItinerantTeamIds') v)
          OR t.setup_id IS DISTINCT FROM (x->>'setupId')::int
          OR t.participant_margin_before_minutes IS DISTINCT FROM (x->>'participantMarginBeforeMinutes')::int
          OR t.participant_margin_after_minutes IS DISTINCT FROM (x->>'participantMarginAfterMinutes')::int
     ) THEN RAISE EXCEPTION 'REFRESH_REPLAY_NOT_MATERIALIZED'; END IF;
  IF NOT EXISTS (SELECT 1 FROM public.plan_optimizer_snapshots o WHERE o.plan_id=p_plan_id
       AND o.source IS NOT DISTINCT FROM optimizer->>'source'
       AND o.editing_mode IS NOT DISTINCT FROM optimizer->>'editingMode'
       AND o.main_zone_id IS NOT DISTINCT FROM (optimizer->>'mainZoneId')::int
       AND o.arrival_plan_template_snapshot_id IS NOT DISTINCT FROM (optimizer#>>'{transport,arrivalPlanTemplateSnapshotId}')::bigint
       AND o.departure_plan_template_snapshot_id IS NOT DISTINCT FROM (optimizer#>>'{transport,departurePlanTemplateSnapshotId}')::bigint
       AND o.arrival_grouping_target IS NOT DISTINCT FROM (optimizer#>>'{transport,arrivalGroupingTarget}')::int
       AND o.departure_grouping_target IS NOT DISTINCT FROM (optimizer#>>'{transport,departureGroupingTarget}')::int
       AND o.arrival_min_gap_minutes IS NOT DISTINCT FROM (optimizer#>>'{transport,arrivalMinGapMinutes}')::int
       AND o.departure_min_gap_minutes IS NOT DISTINCT FROM (optimizer#>>'{transport,departureMinGapMinutes}')::int
       AND o.van_capacity IS NOT DISTINCT FROM (optimizer#>>'{transport,vanCapacity}')::int
       AND o.grouping_weight IS NOT DISTINCT FROM (optimizer#>>'{transport,groupingWeight}')::int
       AND o.near_hard_breaks_max IS NOT DISTINCT FROM (optimizer->>'nearHardBreaksMax')::int
       AND (SELECT count(*) FROM public.plan_optimizer_snapshot_heuristics h WHERE h.snapshot_id=o.id)=jsonb_object_length(optimizer->'heuristics')
       AND NOT EXISTS (
         SELECT 1 FROM jsonb_each(optimizer->'heuristics') expected
         LEFT JOIN public.plan_optimizer_snapshot_heuristics actual ON actual.snapshot_id=o.id AND actual.heuristic_key=expected.key
         WHERE actual.heuristic_key IS NULL
            OR actual.basic_level IS DISTINCT FROM (expected.value->>'basicLevel')::int
            OR actual.advanced_value IS DISTINCT FROM (expected.value->>'advancedValue')::int
       )
       AND (SELECT COALESCE(jsonb_agg(g.zone_id ORDER BY g.zone_id),'[]'::jsonb) FROM public.plan_optimizer_snapshot_grouping_zones g WHERE g.snapshot_id=o.id)
           IS NOT DISTINCT FROM (SELECT COALESCE(jsonb_agg((z#>>'{}')::int ORDER BY (z#>>'{}')::int),'[]'::jsonb) FROM jsonb_array_elements(optimizer->'groupingZoneIds') z))
     THEN RAISE EXCEPTION 'REFRESH_REPLAY_NOT_MATERIALIZED'; END IF;

  INSERT INTO public.plan_config_revisions(plan_id,parent_revision_id,source,fingerprint,identity_json,replay_snapshot_json,diff_json,created_by)
  VALUES(p_plan_id,p_expected_revision,'GENERAL_REFRESH',p_identity->>'configurationFingerprint',p_identity,p_replay,p_diff,p_user_id) RETURNING id INTO new_revision;
  UPDATE public.assisted_planning_sessions SET current_config_revision_id=new_revision,draft_validation_id=NULL,updated_at=now() WHERE id=s.id;
  RETURN new_revision;
END $$;
REVOKE ALL ON FUNCTION public.assisted_apply_config_refresh(integer,uuid,bigint,jsonb,jsonb,jsonb) FROM PUBLIC,anon,authenticated,service_role;
GRANT EXECUTE ON FUNCTION public.assisted_apply_config_refresh(integer,uuid,bigint,jsonb,jsonb,jsonb) TO service_role;
CREATE OR REPLACE FUNCTION public.apply_day_config_operation(
  p_plan_id integer, p_actor uuid, p_operation text, p_payload jsonb,
  p_expected_revision bigint, p_expected_identity jsonb, p_expected_replay jsonb,
  p_candidate_identity jsonb, p_candidate_replay jsonb, p_diff jsonb
) RETURNS bigint LANGUAGE plpgsql SECURITY INVOKER SET search_path=public AS $$
DECLARE p public.plans%ROWTYPE; g public.program_settings%ROWTYPE; cap text;
  parent_revision bigint; new_revision bigint; persisted_fingerprint text;
BEGIN
  SELECT * INTO p FROM public.plans WHERE id=p_plan_id FOR UPDATE;
  IF p.id IS NULL THEN RAISE EXCEPTION 'PLAN_NOT_FOUND'; END IF;
  IF p.current_config_revision_id IS DISTINCT FROM p_expected_revision THEN RAISE EXCEPTION 'STALE_CONFIG_REVISION'; END IF;
  IF p_expected_identity->>'contractVersion'<>'1' OR (p_expected_identity->>'planId')::integer<>p_plan_id
     OR p_expected_replay->>'contractVersion'<>'1' OR p_expected_identity->>'configurationFingerprint' IS NULL
     OR p_candidate_identity->>'contractVersion'<>'1' OR (p_candidate_identity->>'planId')::integer<>p_plan_id
     OR p_candidate_replay->>'contractVersion'<>'1' OR p_candidate_identity->>'configurationFingerprint' IS NULL
     THEN RAISE EXCEPTION 'INVALID_CONFIG_REVISION_CONTRACT'; END IF;

  parent_revision:=p.current_config_revision_id;
  IF parent_revision IS NOT NULL THEN
    SELECT fingerprint INTO persisted_fingerprint FROM public.plan_config_revisions
      WHERE id=parent_revision AND plan_id=p_plan_id FOR UPDATE;
  END IF;
  -- A missing or stale legacy pointer is repaired only with a full canonical
  -- snapshot of the pre-mutation effective configuration.
  IF persisted_fingerprint IS DISTINCT FROM p_expected_identity->>'configurationFingerprint' THEN
    INSERT INTO public.plan_config_revisions(plan_id,parent_revision_id,source,fingerprint,identity_json,replay_snapshot_json,diff_json,created_by)
    VALUES(p_plan_id,parent_revision,'CANONICAL_MATERIALIZATION',p_expected_identity->>'configurationFingerprint',p_expected_identity,p_expected_replay,
      jsonb_build_object('reason','legacy-or-stale-current-revision'),p_actor) RETURNING id INTO parent_revision;
  END IF;

  IF p_operation='EDIT' THEN
    IF p_payload ? 'workday' THEN UPDATE public.plans SET work_start=p_payload#>>'{workday,start}',work_end=p_payload#>>'{workday,end}',work_config_source='DAY_OVERRIDE',work_override_by=p_actor,work_override_at=now() WHERE id=p_plan_id; END IF;
    IF p_payload ? 'meal' THEN UPDATE public.plans SET meal_start=p_payload#>>'{meal,start}',meal_end=p_payload#>>'{meal,end}',meal_mode=p_payload#>>'{meal,mode}',meal_config_source='DAY_OVERRIDE',meal_override_by=p_actor,meal_override_at=now() WHERE id=p_plan_id; END IF;
    IF p_payload ? 'participantTransitionMinutes' THEN UPDATE public.plans SET participant_transition_minutes=(p_payload->>'participantTransitionMinutes')::int,participant_transition_config_source='DAY_OVERRIDE',participant_transition_override_by=p_actor,participant_transition_override_at=now() WHERE id=p_plan_id; END IF;
  ELSIF p_operation='RESTORE' THEN
    cap:=p_payload->>'capability';
    IF cap='WORKDAY_WINDOW' THEN UPDATE public.plans SET work_start=work_baseline_start,work_end=work_baseline_end,work_config_source='INHERITED',work_override_by=NULL,work_override_at=NULL WHERE id=p_plan_id;
    ELSIF cap='GLOBAL_MEAL_BREAK' THEN UPDATE public.plans SET meal_start=meal_baseline_start,meal_end=meal_baseline_end,meal_mode=meal_baseline_mode,meal_config_source='INHERITED',meal_override_by=NULL,meal_override_at=NULL WHERE id=p_plan_id;
    ELSIF cap='PARTICIPANT_TRANSITION' THEN UPDATE public.plans SET participant_transition_minutes=participant_transition_baseline_minutes,participant_transition_config_source='INHERITED',participant_transition_override_by=NULL,participant_transition_override_at=NULL WHERE id=p_plan_id;
    ELSE RAISE EXCEPTION 'INVALID_CAPABILITY'; END IF;
  ELSIF p_operation='REFRESH' THEN
    SELECT * INTO g FROM public.program_settings WHERE id=1;
    IF p_payload->'capabilities' ? 'WORKDAY_WINDOW' AND (p.work_config_source<>'LEGACY_BACKFILL' OR p_payload->>'legacyTreatment'='ADOPT_GENERAL_AS_INHERITED') THEN
      UPDATE public.plans SET work_baseline_start=g.default_work_start,work_baseline_end=g.default_work_end,
        work_start=CASE WHEN p.work_config_source='DAY_OVERRIDE' THEN work_start ELSE g.default_work_start END,
        work_end=CASE WHEN p.work_config_source='DAY_OVERRIDE' THEN work_end ELSE g.default_work_end END,
        work_config_source=CASE WHEN p.work_config_source='LEGACY_BACKFILL' THEN 'INHERITED' ELSE p.work_config_source END,
        work_override_by=CASE WHEN p.work_config_source='DAY_OVERRIDE' THEN work_override_by ELSE NULL END,
        work_override_at=CASE WHEN p.work_config_source='DAY_OVERRIDE' THEN work_override_at ELSE NULL END WHERE id=p_plan_id;
    END IF;
    IF p_payload->'capabilities' ? 'GLOBAL_MEAL_BREAK' AND (p.meal_config_source<>'LEGACY_BACKFILL' OR p_payload->>'legacyTreatment'='ADOPT_GENERAL_AS_INHERITED') THEN
      UPDATE public.plans SET meal_baseline_start=g.meal_start,meal_baseline_end=g.meal_end,meal_baseline_mode=g.meal_mode,
        meal_start=CASE WHEN p.meal_config_source='DAY_OVERRIDE' THEN meal_start ELSE g.meal_start END,
        meal_end=CASE WHEN p.meal_config_source='DAY_OVERRIDE' THEN meal_end ELSE g.meal_end END,
        meal_mode=CASE WHEN p.meal_config_source='DAY_OVERRIDE' THEN meal_mode ELSE g.meal_mode END,
        meal_config_source=CASE WHEN p.meal_config_source='LEGACY_BACKFILL' THEN 'INHERITED' ELSE p.meal_config_source END,
        meal_override_by=CASE WHEN p.meal_config_source='DAY_OVERRIDE' THEN meal_override_by ELSE NULL END,
        meal_override_at=CASE WHEN p.meal_config_source='DAY_OVERRIDE' THEN meal_override_at ELSE NULL END WHERE id=p_plan_id;
    END IF;
    IF p_payload->'capabilities' ? 'PARTICIPANT_TRANSITION' AND (p.participant_transition_config_source<>'LEGACY_BACKFILL' OR p_payload->>'legacyTreatment'='ADOPT_GENERAL_AS_INHERITED') THEN
      UPDATE public.plans SET participant_transition_baseline_minutes=g.default_participant_transition_minutes,
        participant_transition_minutes=CASE WHEN p.participant_transition_config_source='DAY_OVERRIDE' THEN participant_transition_minutes ELSE g.default_participant_transition_minutes END,
        participant_transition_config_source=CASE WHEN p.participant_transition_config_source='LEGACY_BACKFILL' THEN 'INHERITED' ELSE p.participant_transition_config_source END,
        participant_transition_override_by=CASE WHEN p.participant_transition_config_source='DAY_OVERRIDE' THEN participant_transition_override_by ELSE NULL END,
        participant_transition_override_at=CASE WHEN p.participant_transition_config_source='DAY_OVERRIDE' THEN participant_transition_override_at ELSE NULL END WHERE id=p_plan_id;
    END IF;
  ELSE RAISE EXCEPTION 'INVALID_OPERATION'; END IF;

  -- Re-lock/read after mutation and reject a server candidate built for any
  -- different effective workday/meal state. Contestant values are never inferred.
  SELECT * INTO p FROM public.plans WHERE id=p_plan_id;
  IF NOT EXISTS (SELECT 1 FROM jsonb_array_elements(p_candidate_replay#>'{authorities,plan_workday}') w
    WHERE w#>>'{workDay,start}'=p.work_start AND w#>>'{workDay,end}'=p.work_end
      AND w->>'mealMode'=p.meal_mode
      AND (w#>>'{mealWindow,start}'=p.meal_start OR w#>>'{meal,start}'=p.meal_start)
      AND (w#>>'{mealWindow,end}'=p.meal_end OR w#>>'{meal,end}'=p.meal_end)
      AND (w->>'defaultParticipantTransitionMinutes')::int=p.participant_transition_minutes)
    THEN RAISE EXCEPTION 'STALE_CONFIG_CANDIDATE'; END IF;

  INSERT INTO public.plan_config_revisions(plan_id,parent_revision_id,source,fingerprint,identity_json,replay_snapshot_json,diff_json,created_by)
  VALUES(p_plan_id,parent_revision,p_operation,p_candidate_identity->>'configurationFingerprint',p_candidate_identity,p_candidate_replay,p_diff,p_actor)
  RETURNING id INTO new_revision;
  UPDATE public.plans SET current_config_revision_id=new_revision WHERE id=p_plan_id;
  UPDATE public.assisted_planning_sessions SET current_config_revision_id=new_revision,draft_validation_id=NULL,updated_at=now()
    WHERE plan_id=p_plan_id AND status='ACTIVE';
  RETURN new_revision;
END $$;
REVOKE ALL ON FUNCTION public.apply_day_config_operation(integer,uuid,text,jsonb,bigint,jsonb,jsonb,jsonb,jsonb,jsonb) FROM PUBLIC,anon,authenticated,service_role;
GRANT EXECUTE ON FUNCTION public.apply_day_config_operation(integer,uuid,text,jsonb,bigint,jsonb,jsonb,jsonb,jsonb,jsonb) TO service_role;
CREATE OR REPLACE FUNCTION public.initialize_day_config_revision(
  p_plan_id integer, p_actor uuid, p_identity jsonb, p_replay jsonb, p_diff jsonb
) RETURNS bigint LANGUAGE plpgsql SECURITY INVOKER SET search_path=public AS $$
DECLARE p public.plans%ROWTYPE; new_revision bigint;
BEGIN
  SELECT * INTO p FROM public.plans WHERE id=p_plan_id FOR UPDATE;
  IF p.id IS NULL THEN RAISE EXCEPTION 'PLAN_NOT_FOUND'; END IF;
  IF p.current_config_revision_id IS NOT NULL THEN RAISE EXCEPTION 'CONFIG_REVISION_ALREADY_INITIALIZED'; END IF;
  IF p_identity->>'contractVersion'<>'1' OR (p_identity->>'planId')::integer<>p_plan_id
    OR p_identity->>'configurationFingerprint' IS NULL OR p_replay->>'contractVersion'<>'1'
    THEN RAISE EXCEPTION 'INVALID_CONFIG_REVISION_CONTRACT'; END IF;
  INSERT INTO public.plan_config_revisions(plan_id,source,fingerprint,identity_json,replay_snapshot_json,diff_json,created_by)
  VALUES(p_plan_id,'DAY_CREATED',p_identity->>'configurationFingerprint',p_identity,p_replay,p_diff,p_actor)
  RETURNING id INTO new_revision;
  UPDATE public.plans SET current_config_revision_id=new_revision WHERE id=p_plan_id;
  RETURN new_revision;
END $$;
REVOKE ALL ON FUNCTION public.initialize_day_config_revision(integer,uuid,jsonb,jsonb,jsonb) FROM PUBLIC,anon,authenticated,service_role;
GRANT EXECUTE ON FUNCTION public.initialize_day_config_revision(integer,uuid,jsonb,jsonb,jsonb) TO service_role;
NOTIFY pgrst,'reload schema';
COMMIT;